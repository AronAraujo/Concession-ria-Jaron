
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.pessoa;

public class PessoaDAO {

	private Connection connection;
	
	public PessoaDAO(){
	connection= new Concessionaria().getconnection();

	}
	public int inserir(pessoa p) {
	int inseriu=0;
	String sql="Insert into pessoa(Cpf,Nome,RG,logradouro,cidade,pais,estado,data_nasc,CEP,numero) values (?,?,?,?,?,?,?,?,?,?)";
	PreparedStatement stmt;
	try {
				
	stmt=(PreparedStatement) connection.prepareStatement(sql);
	stmt.setString(1, p.getCpf());
	stmt.setString(2, p.getNome());
	stmt.setInt(3, p.getRG());
	stmt.setString(4, p.getLogradouro());
	stmt.setString(5, p.getCidade());
	stmt.setString(6, p.getPais());
	stmt.setString(7, p.getEstado());
	stmt.setString(8, p.getData_nasc());
	stmt.setString(9,p.getCEP());
	stmt.setInt(10, p.getNumero());
	inseriu=stmt.executeUpdate();
	stmt.close();

	}catch(SQLException e) {
	e.printStackTrace();
	}
	
	
	return inseriu;
	}
	public pessoa getPessoa(String Cpf) {
		String sql="SELECT * FROM pessoa WHERE Cpf=?";
		
		try {
			PreparedStatement stmt = this.connection.prepareStatement(sql);
			stmt.setString(1, Cpf);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				pessoa p=new pessoa(Cpf, rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));
				return p;
			}else {
				return null;
			}

		}catch(SQLException e){
			return null;
		}
	}
	public void  editar(pessoa p) {
		String sql="Update pessoa set Nome=?, RG=?, logradouro=?, cidade=?, pais=?, estado=?, data_nasc=?, CEP=?, numero=? where Cpf=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, p.getNome());
			stmt.setFloat(2, p.getRG());
			stmt.setString(3, p.getLogradouro());
			stmt.setString(4, p.getCidade());
			stmt.setString(5, p.getPais());
			stmt.setString(6, p.getEstado());
			stmt.setString(7, p.getData_nasc());
			stmt.setString(8, p.getCEP());
			stmt.setInt(9, p.getNumero());
			stmt.setString(10, p.getCpf());
			stmt.execute();
		}catch (Exception e){
			System.out.println("Erro ao atualizar pessoa!");
		}
	}
	public void deletar(String Cpf) {
		String sql="Delete from pessoa where Cpf=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, Cpf);
			stmt.execute();
		}catch(Exception e) {
			System.out.println("Erro ao excluir pessoa" + e.getMessage());
		}
	}
	public List<pessoa> listar(String Nome){
		String sql="select * from pessoa where Nome like ?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, "%"+ Nome +"%" );
			ResultSet rs=stmt.executeQuery();
			List<pessoa> lista=new ArrayList<>();
			while(rs.next()) {
				pessoa p=new pessoa(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));
				lista.add(p);
			}
			return lista;
		}catch (Exception e){
			return null;
		}
	}
	public List<pessoa> listarsemc(){
		String sql="SELECT pessoa.*\r\n"
				+ "FROM pessoa\r\n"
				+ "LEFT JOIN cliente ON pessoa.Cpf = cliente.CpfP\r\n"
				+ "WHERE cliente.CpfP IS NULL;";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			List<pessoa> lista=new ArrayList<>();
			while(rs.next()) {
				pessoa p=new pessoa(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));
				lista.add(p);
			}
			return lista;
		}catch (Exception e){
			return null;
		}
	}
	
	public List<pessoa> listarsemf(){
		String sql="SELECT pessoa.*\r\n"
				+ "FROM pessoa\r\n"
				+ "LEFT JOIN funcionario ON pessoa.Cpf = funcionario.CpfP\r\n"
				+ "WHERE funcionario.CpfP IS NULL;";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			List<pessoa> lista=new ArrayList<>();
			while(rs.next()) {
				pessoa p=new pessoa(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));
				lista.add(p);
			}
			return lista;
		}catch (Exception e){
			return null;
		}
	}
}
