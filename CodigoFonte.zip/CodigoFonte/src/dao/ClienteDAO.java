package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Cliente;
import bean.ClienteMaisCompras;

import java.lang.String;


public class ClienteDAO {
	private Connection connection;

	public ClienteDAO(){
	connection= new Concessionaria().getconnection();

	}
	public int inserir(Cliente c) {
		int inseriu=0;
		String sql="INSERT INTO cliente (CpfP, CNH) VALUES (?,?)";
		PreparedStatement stmt;	
		try {
			  	stmt=(PreparedStatement)connection.prepareStatement(sql);
			    	
				stmt.setString(1, c.getCpf());
				stmt.setInt(2, c.getCNH());
				
					
				inseriu=stmt.executeUpdate();
				stmt.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}
	

	public Cliente getCliente(String CpfP) {
		String sql="SELECT c.CpfP, c.CNH, p.Nome,p.RG,p.logradouro,p.cidade,p.pais,p.estado,p.data_nasc,p.CEP,p.numero  from cliente c ,pessoa p where c.CpfP=p.Cpf and CpfP=?";

		try {
			PreparedStatement stmt = this.connection.prepareStatement(sql);
			stmt.setString(1, CpfP);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				
				Cliente c = new Cliente(CpfP, rs.getInt(2), rs.getString(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getInt(11));
				return c;
			}else {
				System.out.print("ok");
				return null;
			}
        } catch (SQLException e) {
        	System.out.print("ok");
            return null;
        }

    }

  
    
	public void  editar(Cliente c ) {
		String sql="Update cliente SET CNH=?  WHERE CpfP=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setInt(1, c.getCNH());
			stmt.setString(2, c.getCpf());
			stmt.execute();
		}catch (Exception e){
			System.out.println("Erro ao atualizar cliente!");
		}
	}
	public boolean deletar(String CpfP) {
		String sql="Delete from cliente where CpfP=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, CpfP);
			stmt.execute();
			return true;
		}catch(Exception e) {
			return false;
		}
	}
	public List<Cliente> listarTodos() {
	    
	    String query = "select p.*, c.CNH from pessoa p inner join cliente c on p.Cpf=c.CpfP";
	    try {
	    	PreparedStatement stmt=this.connection.prepareStatement(query);
	    	ResultSet rs=stmt.executeQuery();
	    	List<Cliente> lista=new ArrayList<>();
	    	while(rs.next()) {
	            Cliente cliente = new Cliente(rs.getString(1), rs.getInt(11), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));
	            lista.add(cliente);
	    	}
	    	return lista;
	    	
	    }catch(Exception e) {
	    	return null;
	    }

	}
	
public List<Cliente> listarTodosN(String Nome) {
    String query = "select p.*, c.CNH from pessoa p inner join cliente c on p.Cpf=c.CpfP WHERE p.Nome like ?";
    try {
        PreparedStatement stmt = this.connection.prepareStatement(query);
        stmt.setString(1, "%" + Nome + "%"); // Set the parameter before executing the query
        ResultSet rs = stmt.executeQuery();

        List<Cliente> lista = new ArrayList<>();
        while (rs.next()) {
            Cliente cliente = new Cliente(rs.getString(1), rs.getInt(11), rs.getString(2), rs.getInt(3),
                    rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),
                    rs.getString(9), rs.getInt(10));
            lista.add(cliente);
        }
        return lista;
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}

	
	
	public List<ClienteMaisCompras> listarClientesMaisCompras(String Nome) {
        String sql = "SELECT cliente.CpfP, pessoa.Nome AS nome_cliente, cliente.CNH, COUNT(*) AS total_compras " +
                     "FROM compra_venda " +
                     "JOIN cliente ON compra_venda.Cliente = cliente.CpfP " +
                     "JOIN pessoa ON cliente.CpfP = pessoa.Cpf " +
                     "WHERE pessoa.Nome LIKE ?"+
                     "GROUP BY cliente.CpfP, pessoa.Nome, cliente.CNH " +
                     "ORDER BY total_compras DESC";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        	stmt.setString(1, "%" + Nome + "%");
            ResultSet rs = stmt.executeQuery();
        	
            List<ClienteMaisCompras> lista = new ArrayList<>();
            while (rs.next()) {
                String cpfCliente = rs.getString("CpfP");
                String nomeCliente = rs.getString("nome_cliente");
                String cnhCliente = rs.getString("CNH");
                int totalCompras = rs.getInt("total_compras");

                ClienteMaisCompras clienteMaisCompras = new ClienteMaisCompras(cpfCliente, nomeCliente, cnhCliente, totalCompras);
                lista.add(clienteMaisCompras);
            }

            return lista;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
	
}
