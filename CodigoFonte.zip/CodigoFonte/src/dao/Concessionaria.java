package dao;

import java.sql.Connection;
import java.sql.DriverManager;
public class Concessionaria {
	public Connection getconnection(){
		try {
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/concessionaria",
					"root",
					""
					);
			return conn;
		}catch(Exception e){
			System.out.println("Erro oa conectar "+ e.getMessage());
			return null;
		}
	}
}
