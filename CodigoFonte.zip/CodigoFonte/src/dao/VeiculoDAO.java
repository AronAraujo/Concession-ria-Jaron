package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Cliente;
import bean.ModeloMarcaVeiculoVendas;

import bean.veiculo;
import bean.vendaMaisCara;

public class VeiculoDAO {
	private Connection connection;

	public VeiculoDAO(){
	connection= new Concessionaria().getconnection();

	}
	public int inserir(veiculo v) {
	int inseriu=0;
	String sql="Insert into veiculo(Chassi, cor, modelo, marca, placa, ano ,valor) values (?,?,?,?,?,?,?)";
	PreparedStatement stmt;
	try {
				
	stmt=(PreparedStatement) connection.prepareStatement(sql);
	stmt.setString(1, v.getChassi());
	stmt.setString(2, v.getCor());
	stmt.setString(3, v.getModelo());
	stmt.setString(4, v.getMarca());
	stmt.setString(5, v.getPlaca());
	stmt.setString(6, v.getAno());
	stmt.setDouble(7, v.getValor());

	inseriu=stmt.executeUpdate();
	stmt.close();

	}catch(SQLException e) {
	e.printStackTrace();
	}
	
	
	return inseriu;
	}
	public veiculo getVeiculo(String Chassi) {
		String sql="SELECT * FROM veiculo WHERE Chassi=?";
		
		try {
			PreparedStatement stmt = this.connection.prepareStatement(sql);
			stmt.setString(1, Chassi);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				veiculo p=new veiculo(Chassi, rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getDouble(7));
				return p;
			}else {
				return null;
			}

		}catch(SQLException e){
			return null;
		}
	}
	
	
	public void  editar(veiculo v) {
		String sql="Update veiculo set cor=?, modelo=?, marca=?, placa=?, ano=?, valor=? where Chassi=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, v.getCor());
			stmt.setString(2, v.getModelo());
			stmt.setString(3, v.getMarca());
			stmt.setString(4, v.getPlaca());
			stmt.setString(5, v.getAno());
			stmt.setDouble(6, v.getValor());
			stmt.setString(7, v.getChassi());
			
			stmt.execute();
		}catch (Exception e){
			System.out.println("Erro ao atualizar veiculo!");
		}
	}
	public boolean deletar(String Chassi) {
		String sql="Delete from veiculo where Chassi=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, Chassi);
			stmt.execute();
			return true;
		}catch(Exception e) {
			return false;
		}
		
	}
	
	
	public List<veiculo> listarTodos( ){
		String sql="select * from veiculo";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			ResultSet rs=stmt.executeQuery();
			List<veiculo> lista=new ArrayList<>();
			while(rs.next()) {
				veiculo v=new veiculo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getDouble(7));
				lista.add(v);
			}
			return lista;
		}catch (Exception e){
			return null;
		}
	}
	
	
	
	
	
	public List<veiculo> listar(String placa){
		String sql="select * from veiculo where placa like ?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, "%"+ placa +"%" );
			ResultSet rs=stmt.executeQuery();
			List<veiculo> lista=new ArrayList<>();
			while(rs.next()) {
				veiculo v=new veiculo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getDouble(7));
				lista.add(v);
			}
			return lista;
		}catch (Exception e){
			return null;
		}
	}
	
	
	public List<ModeloMarcaVeiculoVendas> listarModelosMaisVendidosComMarca(String Modelo) {
        String sql = "SELECT veiculo.modelo, veiculo.marca, COUNT(*) AS total_vendas " +
                     "FROM compra_venda " +
                     "JOIN veiculo ON compra_venda.Veiculo = veiculo.Chassi " +
                     "WHERE veiculo.modelo like ?"+
                     "GROUP BY veiculo.modelo " +
                     "ORDER BY total_vendas DESC";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
        	stmt.setString(1, "%" + Modelo + "%");
            ResultSet rs = stmt.executeQuery();

            List<ModeloMarcaVeiculoVendas> lista = new ArrayList<>();
            while (rs.next()) {
                String modelo = rs.getString("modelo");
                String marca = rs.getString("marca");
                int totalVendas = rs.getInt("total_vendas");

                ModeloMarcaVeiculoVendas modeloMarcaVeiculoVendas = new ModeloMarcaVeiculoVendas(modelo, marca, totalVendas);
                lista.add(modeloMarcaVeiculoVendas);
            }

            return lista;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
   }
	
	public List<veiculo> listarcma(String Ano) {
	    String sql = "SELECT * FROM veiculo WHERE veiculo.ano LIKE ? ORDER BY ano DESC;";
	    try {
	        PreparedStatement stmt = this.connection.prepareStatement(sql);
	        stmt.setString(1, "%" + Ano + "%"); // Defina o valor do parâmetro antes de executar a consulta
	        ResultSet rs = stmt.executeQuery();

	        List<veiculo> lista = new ArrayList<>();
	        while (rs.next()) {
	            veiculo v = new veiculo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getDouble(7));
	            lista.add(v);
	        }
	        return lista;
	    } catch (Exception e) {
	        e.printStackTrace(); // Considere imprimir ou lidar com a exceção de alguma forma adequada
	        return null;
	    }
	}
	public List<vendaMaisCara> listarvmc(double valor) {
	    String sql = "SELECT veiculo.*, compra_venda.Funcionario, compra_venda.Cliente, compra_venda.data, compra_venda.hora "
	                + "FROM veiculo " + "JOIN compra_venda ON veiculo.Chassi = compra_venda.Veiculo "
	                + "WHERE veiculo.valor >= ?"
	                + "ORDER BY veiculo.valor DESC;";

	    try {
	        PreparedStatement stmt = this.connection.prepareStatement(sql);
	        stmt.setDouble(1, valor);  // Set the parameter before executing the query
	        ResultSet rs = stmt.executeQuery();
	        List<vendaMaisCara> lista = new ArrayList<>();
	        while (rs.next()) {
	            vendaMaisCara veiculoCompraVenda = new vendaMaisCara(rs.getString(1), rs.getString(2),
	                    rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getDouble(7),
	                    rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11));
	            lista.add(veiculoCompraVenda);
	        }
	        return lista;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	
	public List<veiculo> listarVeiculosPorValor(double valor) {
	    String sql = "SELECT * FROM veiculo WHERE valor >= ? ORDER BY valor DESC;";
	    
	    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	        stmt.setDouble(1, valor);
	        ResultSet rs = stmt.executeQuery();

	        List<veiculo> lista = new ArrayList<>();
	        while (rs.next()) {
	            veiculo veiculo = new veiculo(
	                rs.getString("Chassi"),
	                rs.getString("cor"),
	                rs.getString("modelo"),
	                rs.getString("marca"),
	                rs.getString("placa"),
	                rs.getString("ano"),
	                rs.getDouble("valor")
	            );
	            lista.add(veiculo);
	        }

	        return lista;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	}
	public boolean verificar(String chassi) {
		List<veiculo> lista=listarTodos();
		for(veiculo v: lista) {
			if(v.getChassi().equals(chassi)) {
				return true;
			}
		}
		return false;
	}

	
}
