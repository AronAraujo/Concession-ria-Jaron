package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.compra_venda;
import bean.pessoa;
import bean.veiculo;



public class Compra_vendaDAO {

	private   Connection connection;
	
	public Compra_vendaDAO(){
	connection= new Concessionaria().getconnection();

	}
	
	
	
	public boolean chassiJaCadastrado(String chassi) {
	    String sql = "SELECT COUNT(*) FROM compra_venda WHERE chassi = ?";
	    try {
	        PreparedStatement stmt = this.connection.prepareStatement(sql);
	        stmt.setString(1, chassi);
	        ResultSet rs = stmt.executeQuery();
	        rs.next();
	        int count = rs.getInt(1);
	        return count > 0;
	    } catch (Exception e) {
	        e.printStackTrace();
	        return false;
	    }
	}
    public int inserir(compra_venda cpv) {
    	int inseriu=0;
    	String sql = "INSERT INTO compra_venda (Veiculo, Funcionario, Cliente, data, hora) VALUES (?, ?, ?, ?, ?)";
    	PreparedStatement stmt;
    	try {
    		stmt=(PreparedStatement) connection.prepareStatement(sql);
    		stmt.setString(1, cpv.getVeiculo());
    		stmt.setString(2, cpv.getFuncionario());
    		stmt.setString(3, cpv.getCliente());
    		stmt.setString(4, cpv.getData());
    		stmt.setString(5, cpv.getHora());
    		stmt.executeUpdate();
    		stmt.close();

    		}catch(SQLException e) {
    		e.printStackTrace();
    		}
    		
    		
    		return inseriu;
    		}
    
    public void editar(compra_venda cv) {
        String sql = "UPDATE compra_venda SET data=?, hora=? WHERE Veiculo=? AND Funcionario=? AND Cliente=?";
        try {
            PreparedStatement stmt = this.connection.prepareStatement(sql);
            stmt.setString(1, cv.getData());
            stmt.setString(2, cv.getHora());
            stmt.setString(3, cv.getVeiculo());
            stmt.setString(4, cv.getFuncionario());
            stmt.setString(5, cv.getCliente());
            stmt.executeUpdate();
        } catch (Exception e) {
            System.out.println("Erro ao editar venda: " + e.getMessage());
        }
    }

       
    
    public  compra_venda getCompra_veda(String Veiculo ,String Funcionario ,String Cliente) {
		String sql="SELECT * FROM compra_venda WHERE Veiculo = ? AND Funcionario = ? AND Cliente = ?";
		
		try {
			PreparedStatement stmt = this.connection.prepareStatement(sql);
			stmt.setString(1, Veiculo);
			stmt.setString(2, Funcionario);
			stmt.setString(3, Cliente);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				compra_venda cv=new compra_venda(Veiculo,Funcionario,Cliente, rs.getString(4),  rs.getString(5));
				return cv;
			}else {
				return null;
			}

		}catch(SQLException e){
			return null;
		}
	}    

    

    
    
    
    public void deletar(String Veiculo,  String Funcionario,String Cliente){
        String sql = "DELETE FROM compra_venda WHERE Veiculo = ? AND Funcionario = ? AND Cliente = ? ";
        try{
        	PreparedStatement stmt=this.connection.prepareStatement(sql);
        	stmt.setString(1, Veiculo);
        	stmt.setString(2, Funcionario);
        	stmt.setString(3, Cliente);
        	stmt.execute();
        	System.out.println("Boa" );
        }catch(Exception e) {
			System.out.println("Erro ao excluir pessoa" + e.getMessage());
		} 	
        
    }

    public List<compra_venda> listarTodasCompraVenda(String data){
       
        String sql = "SELECT * FROM compra_venda where data like ?";
        try {
            PreparedStatement stmt= connection.prepareStatement(sql);
            stmt.setString(1, "%"+ data +"%" );
 			ResultSet rs=stmt.executeQuery();
 			List<compra_venda> lista=new ArrayList<>();
            while (rs.next()) {
				compra_venda cv=new compra_venda(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				lista.add(cv);

            }
            return lista;
        }catch (Exception e){
        	return null;
        }
    }
    
    public List<compra_venda> listarTodasString(){
        
        String sql = "SELECT * FROM compra_venda";
        try {
            PreparedStatement stmt= connection.prepareStatement(sql);
        
 			ResultSet rs=stmt.executeQuery();
 			List<compra_venda> lista=new ArrayList<>();
            while (rs.next()) {
				compra_venda cv=new compra_venda(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				lista.add(cv);

            }
            return lista;
        }catch (Exception e){
        	return null;
        }
    }
    public boolean verificar(String chassi ,String funcionario, String Cli) {
		List<compra_venda> lista=listarTodasString();
		for(compra_venda v: lista) {
			if(v.getVeiculo().equals(chassi) && v.getFuncionario().equals(funcionario) && v.getCliente().equals(Cli)) {
				return true;
			}
		}
		return false;
	}
    
}

