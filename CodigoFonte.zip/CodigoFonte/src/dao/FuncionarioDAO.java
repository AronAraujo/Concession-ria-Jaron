package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Cliente;
import bean.funcionario;

public class FuncionarioDAO {
    private Connection connection;


	public FuncionarioDAO(){
	connection= new Concessionaria().getconnection();

	}

	public int inserir(funcionario f) {
		int inseriu=0;
		String sql="INSERT INTO funcionario (CpfP, salario, data_adimissao,meta, RegistroFaturamento, comissao) VALUES (?,?,?,?,?,?)";
		PreparedStatement stmt;	
		try {
			  	stmt=(PreparedStatement)connection.prepareStatement(sql);
			    	
				stmt.setString(1, f.getCpf());
				stmt.setDouble(2, f.getSalario());
				stmt.setString(3, f.getData_adimissao());
				stmt.setDouble(4, f.getMeta());
				stmt.setDouble(5, f.getRegistroFaturamento());
				stmt.setDouble(6, f.getComissao());	
				inseriu=stmt.executeUpdate();
				stmt.close();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return inseriu;
	}

	
	public void  editar(funcionario f ) {
		String sql="Update funcionario SET salario=?,data_adimissao=? ,RegistroFaturamento=?,meta=?,comissao=? WHERE CpfP=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setDouble(1, f.getSalario());
			stmt.setString(2, f.getData_adimissao());			
			stmt.setDouble(3, f.getMeta());
			stmt.setDouble(4, f.getRegistroFaturamento());
			stmt.setDouble(5, f.getComissao());
			stmt.setString(6, f.getCpf());
			stmt.execute();
		}catch (Exception e){
			System.out.println("Erro ao atualizar cliente!");
		}
	}
	
	
	
	public List<funcionario> listarTodosN(String Nome) {
	    List<funcionario> funcionario = new ArrayList<>();
        String query = "SELECT p.*, f.salario, f.data_adimissao, f.meta, f.RegistroFaturamento, f.comissao FROM pessoa p INNER JOIN funcionario f ON p.Cpf=f.CpfP WHERE Nome like ?";


	    try  {
	    	PreparedStatement stmt=this.connection.prepareStatement(query);
			stmt.setString(1, "%"+ Nome +"%" );
			ResultSet rs=stmt.executeQuery();
	        while (rs.next()) {
	            funcionario f = criarfuncionarioAPartirDoResultSet(rs);
	            funcionario.add(f);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return funcionario;
	    }
	public List<funcionario> listarTodos() {
	    List<funcionario> funcionario = new ArrayList<>();
        String query = "SELECT p.*, f.salario, f.data_adimissao, f.meta, f.RegistroFaturamento, f.comissao FROM pessoa p INNER JOIN funcionario f ON p.Cpf=f.CpfP";


	    try  {
	    	PreparedStatement stmt=this.connection.prepareStatement(query);
			
			ResultSet rs=stmt.executeQuery();
	        while (rs.next()) {
	            funcionario f = criarfuncionarioAPartirDoResultSet(rs);
	            funcionario.add(f);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return funcionario;
	    }
	
	public boolean deletar(String CpfP) {
		String sql="Delete from funcionario where CpfP=?";
		try {
			PreparedStatement stmt=this.connection.prepareStatement(sql);
			stmt.setString(1, CpfP);
			stmt.execute();
			return true;
		}catch(Exception e) {
			return false;
		}
	}
	
	public funcionario getFuncionario(String CpfP) {
		String sql="SELECT p.Cpf, f.salario, f.data_adimissao, f.meta, f.RegistroFaturamento, f.comissao,p.Nome, p.RG, p.logradouro, p.cidade, p.pais, p.estado, p.data_nasc, p.CEP, p.numero from funcionario f,pessoa p where f.CpfP=p.Cpf and CpfP=?;";

		try {
			PreparedStatement stmt = this.connection.prepareStatement(sql);
			stmt.setString(1, CpfP);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				funcionario c = new funcionario(CpfP, rs.getDouble(2), rs.getString(3),rs.getDouble(4),rs.getDouble(5),rs.getDouble(6),rs.getString(7), rs.getInt(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14), rs.getInt(15));
				return c;
				
			}else {
				
				return null;
			}
        } catch (SQLException e) {
        	
            return null;
        }

    }
	
            public List<funcionario> listarfqmv() {
        	    List<funcionario> funcionario = new ArrayList<>();
                String sql = "SELECT pessoa.Cpf, funcionario.salario, funcionario.data_adimissao, funcionario.meta, funcionario.RegistroFaturamento, funcionario.comissao,pessoa.Nome, pessoa.RG, pessoa.logradouro, pessoa.cidade, pessoa.pais, pessoa.estado, pessoa.data_nasc, pessoa.CEP, pessoa.numero FROM pessoa  JOIN funcionario  ON pessoa.Cpf = funcionario.CpfP ORDER BY  funcionario.RegistroFaturamento DESC;";

        	    try (PreparedStatement stmt = connection.prepareStatement(sql);
        	         ResultSet rs = stmt.executeQuery()) {

        	        while (rs.next()) {
        	            funcionario f = criarfuncionarioAPartirDoResultSet(rs);
        	            funcionario.add(f);
        	        }
        	    } catch (SQLException e) {
        	        e.printStackTrace();
        	    }

        	    return funcionario;
        	}
            
            public List<funcionario> listafqmv(String Nome) {
        	   
                String sql = "SELECT pessoa.Cpf, funcionario.salario, funcionario.data_adimissao, funcionario.meta, funcionario.RegistroFaturamento, funcionario.comissao, pessoa.Nome, pessoa.RG, pessoa.logradouro, pessoa.cidade, pessoa.pais, pessoa.estado, pessoa.data_nasc, pessoa.CEP, pessoa.numero \r\n"
                		+ "FROM pessoa \r\n"
                		+ "JOIN funcionario ON pessoa.Cpf = funcionario.CpfP \r\n"
                		+ "WHERE pessoa.Nome LIKE ? \r\n"
                		+ "ORDER BY funcionario.RegistroFaturamento DESC;\r\n"
                		+ "";

        	    try {
        	    	PreparedStatement stmt = connection.prepareStatement(sql);
        	    	stmt.setString(1, "%"+ Nome +"%" );
        	        ResultSet rs = stmt.executeQuery();
        	        List<funcionario> funcionario = new ArrayList<>();
        	    	
        	        while (rs.next()) {
        	            funcionario f = criarfuncionarioAPartirDoResultSet(rs);
        	            funcionario.add(f);
        	        }
        	        return funcionario;
        		}catch (Exception e){
        			return null;
        		}
        	}

        	private funcionario criarfuncionarioAPartirDoResultSet(ResultSet rs) {
        	    try {
        	        String Cpf = rs.getString("Cpf");
        	        double salario = rs.getDouble("salario");
        	        String data_adimissao = rs.getString("data_adimissao");
        	        double meta = rs.getDouble("meta");
        	        double RegistroFaturamento = rs.getDouble("RegistroFaturamento");
        	        double comissao = rs.getDouble("comissao");

        	        funcionario f = new funcionario(
        	            Cpf, salario, data_adimissao, meta, RegistroFaturamento, comissao,
        	            rs.getString("Nome"), rs.getInt("RG"), rs.getString("logradouro"),
        	            rs.getString("cidade"), rs.getString("pais"), rs.getString("estado"),
        	            rs.getString("data_nasc"), rs.getString("CEP"), rs.getInt("numero")
        	        );

        	        return f;
        	    } catch (SQLException e) {
        	        e.printStackTrace();
        	        return null;
        	    }
        	}

    
    }



