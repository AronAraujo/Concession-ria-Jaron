package principal;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.funcionario;
import bean.pessoa;

import javax.swing.JScrollPane;

import dao.FuncionarioDAO;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import javax.swing.JButton;


public class Rfqmv extends JFrame {
	
	
	private void preencheTabela(){
		
		FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		String Nome = txtNome.getText();
		List<funcionario>  Lista= funcionarioDAO.listafqmv(Nome);
		
		DefaultTableModel tabelaPessoa = (DefaultTableModel) tblpessoas.getModel();
		tabelaPessoa.setNumRows(0);
		for(funcionario p : Lista) {
			Object[] obj = new Object[] {
				p.getCpf(),
				p.getNome(),
				p.getRegistroFaturamento(),
				p.getSalario(),
				p.getData_adimissao(),
				p.getMeta(),
				p.getComissao(),
				p.getRG(),
				p.getData_nasc(),
				p.getLogradouro(),
				p.getNumero(),
				p.getCidade(),
				p.getPais(),
				p.getEstado(),
				p.getCEP(),
			};
			tabelaPessoa.addRow(obj);
		}
	}
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblpessoas;
	private JScrollPane scrollPane;
	private JTextField txtNome;
	private JButton btnVoltar;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rfqmv frame = new Rfqmv();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Rfqmv() {
		
	
		
		    
	
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 853, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));
		contentPane.setForeground(new Color(165, 162, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 238, 819, 186);
		contentPane.add(scrollPane);
		
		tblpessoas = new JTable();
		tblpessoas.setBorder(UIManager.getBorder("RadioButton.border"));
		tblpessoas.setForeground(new Color(0, 0, 0));
		tblpessoas.setToolTipText("");
		tblpessoas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblpessoas);
		tblpessoas.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Cpf", "Nome", "RF","salario","data de adimissão","meta","comissão", "RG","Nascimento", "Log", "Num", "Cidade", "Pais", "Estado", "CEP"
			}
		));
		
		JLabel lblRelatrioDePessoas = new JLabel("Relatório de Funcionários");
		lblRelatrioDePessoas.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblRelatrioDePessoas.setBounds(10, 199, 220, 44);
		contentPane.add(lblRelatrioDePessoas);
		JLabel lblNewLabel_1 = new JLabel("Opções do Relatório:");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(100, 116, 214, 19);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String OpSlct = comboBox.getSelectedItem().toString();
				if(OpSlct == "Carro mais caro") {
					Rcmc Opcmc = new Rcmc();
					Opcmc.setVisible(true);
					dispose();
				}else if(OpSlct == "Carro mais vendido") {
					Rcmv Opcmv= new Rcmv();
					Opcmv.setVisible(true);
					dispose();
				}else if(OpSlct == "Venda mais cara") {
					Rvmc Opvmc = new Rvmc();
					Opvmc.setVisible(true);
					dispose();
				}else if(OpSlct == "Carro mais atual") {
					Rcma Opcma = new Rcma();
					Opcma.setVisible(true);
					dispose();
				}else if(OpSlct == "Cliente que mais comprou") {
					Rcqmc Opcqmc = new Rcqmc();
					Opcqmc.setVisible(true);
					dispose();
				}else if(OpSlct == "") {
					JOptionPane.showMessageDialog( comboBox, "Opçõa não é valida", null, DO_NOTHING_ON_CLOSE);
				}
			}
		});
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Carro mais caro", "Carro mais vendido", "Carro mais atual", "Cliente que mais comprou", "Venda mais cara"}));
		comboBox.setBounds(309, 110, 321, 31);
		contentPane.add(comboBox);
		
		    // ... (seu código existente)

		    txtNome = new JTextField();
		    txtNome.addCaretListener(new CaretListener() {
		        public void caretUpdate(CaretEvent e) {
		            preencheTabela();
		        }
		    });
		    txtNome.setBounds(309, 169, 320, 30);
		    contentPane.add(txtNome);
		    txtNome.setColumns(10);
		    
		    btnVoltar = new JButton("Voltar");
		    btnVoltar.addActionListener(new ActionListener() {
		    	public void actionPerformed(ActionEvent e) {
		    		main m = new main();
					m.setVisible(true);
					dispose();
		    	}
		    });
		    btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		    btnVoltar.setBackground(new Color(218, 232, 236));
		    btnVoltar.setBounds(10, 10, 86, 20);
		    contentPane.add(btnVoltar);
		    
		    JLabel lblNewLabel_1_1 = new JLabel("Buscar por Nome:");
		    lblNewLabel_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		    lblNewLabel_1_1.setBounds(100, 170, 214, 19);
		    contentPane.add(lblNewLabel_1_1);

		    // Mova a chamada para preencheTabela para depois de inicializar txtNome
		    preencheTabela(); 
		

		
		
	}
}
