package principal;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import dao.ClienteDAO;
import dao.Compra_vendaDAO;
import dao.FuncionarioDAO;
import dao.PessoaDAO;
import dao.VeiculoDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;

import bean.Cliente;
import bean.compra_venda;
import bean.funcionario;
import bean.pessoa;
import bean.veiculo;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;

public class CrudCV extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JFormattedTextField textdata;

	private JLabel lblNewLabel_1;
	private JLabel lblCadastroVeiculo;
	private JButton btnEDITAR;
	private JButton btnEXCLUIR;
	private JLabel lblPesquisarPessoa;
	private JTextField texthora;

	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrudCV frame = new CrudCV();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the frame.
	 */
	public CrudCV() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 599);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		

		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(20, 340, 235, 25);
		contentPane.add(comboBox);
		VeiculoDAO vdao=new VeiculoDAO();
		List<veiculo> lista=vdao.listarTodos();
		for(veiculo v:lista) {
			comboBox.addItem(v.getPlaca()+ "  -" + v.getChassi());
		}
		
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(265, 340, 235, 25);
		contentPane.add(comboBox_1);
		ClienteDAO cdao=new ClienteDAO();
		List<Cliente> listaC=cdao.listarTodos();
		for(Cliente c:listaC) {
			comboBox_1.addItem(c.getCpf() + "-" + c.getNome());
		}
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(510, 340, 235, 25);
		contentPane.add(comboBox_2);
		FuncionarioDAO fdao=new FuncionarioDAO();
		List<funcionario> listaF=fdao.listarTodos();
		for(funcionario f:listaF) {
			comboBox_2.addItem(f.getCpf() + "-" + f.getNome());
		}
		
		
		
		JButton btnCADASTRA = new JButton("Cadastrar");
		btnCADASTRA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCADASTRA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Compra_vendaDAO cvdao=new Compra_vendaDAO();
				String x = comboBox.getSelectedItem().toString();
				int y = x.indexOf("-");
				String novoChassi = x.substring(y + 1);
				
				String cpfF=comboBox_2.getSelectedItem().toString();
				int indic=cpfF.indexOf("-");
				String novoCPFf=cpfF.substring(0, indic);
				
				String cpf=comboBox_1.getSelectedItem().toString();
				int indice=cpf.indexOf("-");
				String novoCPF=cpf.substring(0, indice);
				if(cvdao.verificar(novoChassi,novoCPFf,novoCPF)) {
					JOptionPane.showMessageDialog(contentPane, "Venda ja cadastrado");
				}else {
					
					if(validar()) {
						String CpfC = novoCPF;
						String CpfF= novoCPFf;
						String Chasi = novoChassi;
				
						compra_venda cv=new compra_venda(Chasi,CpfF,CpfC,textdata.getText(),texthora.getText());
				
						cvdao.inserir(cv);
						textdata.setText("");
						texthora.setText("");
				
				}
			}
			}
		});
		btnCADASTRA.setBackground(new Color(218, 232, 236));
		btnCADASTRA.setBounds(245, 501, 120, 35);
		contentPane.add(btnCADASTRA);
		
		textdata = new JFormattedTextField();
		textdata.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textdata.setForeground(new Color(0, 0, 0));
		textdata.setBackground(new Color(255, 255, 255));
		textdata.setBounds(70, 400, 200, 25);
		contentPane.add(textdata);
		textdata.setColumns(10);
		
		JComboBox comboBoxP = new JComboBox();
		comboBoxP.setBounds(20, 180, 235, 25);
		contentPane.add(comboBoxP);
		List<veiculo> l=vdao.listarTodos();
		for(veiculo v:l) {
			comboBoxP.addItem(v.getPlaca()+ "  -" + v.getChassi());
		}
		
		
		///////////////////////////////////////////////////////
		JComboBox comboBoxP1 = new JComboBox();
		comboBoxP1.setBounds(265, 180, 235, 25);
		contentPane.add(comboBoxP1);
		for(Cliente c1:listaC) {
			comboBoxP1.addItem(c1.getCpf() + "-" + c1.getNome());
		}
		
		///////////////////////////////////////////////////////

		JComboBox comboBoxP2 = new JComboBox();
		comboBoxP2.setBounds(510, 180, 235, 25);
		contentPane.add(comboBoxP2);
		for(funcionario f:listaF) {
			comboBoxP2.addItem(f.getCpf() + "-" + f.getNome());
		}
		
		
		
		lblNewLabel_1 = new JLabel("Data:");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(20, 400, 85, 20);
		contentPane.add(lblNewLabel_1);
		
		lblCadastroVeiculo = new JLabel("Cadastrar Venda:");
		lblCadastroVeiculo.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 22));
		lblCadastroVeiculo.setBounds(20, 270, 332, 44);
		contentPane.add(lblCadastroVeiculo);
		
		JLabel lblPesquisarVeiculo = new JLabel("Pesquisar Venda:");
		lblPesquisarVeiculo.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 22));
		lblPesquisarVeiculo.setBounds(20, 96, 345, 44);
		contentPane.add(lblPesquisarVeiculo);
		
		JButton btnPESQUISA = new JButton("Pesquisar");
		btnPESQUISA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String x = comboBoxP.getSelectedItem().toString();
				int y = x.indexOf("-");
				String novoChss = x.substring(y + 1);
				
				String CPFC=comboBoxP1.getSelectedItem().toString();
				int cp=CPFC.indexOf("-");
				String novoCPFC=CPFC.substring(0, cp);
				
				String CPFF=comboBoxP2.getSelectedItem().toString();
				int z=CPFF.indexOf("-");
				String novoCPFF=CPFF.substring(0, z);
				
				
				
				Compra_vendaDAO cvDAO = new Compra_vendaDAO();
				compra_venda cv = cvDAO.getCompra_veda(novoChss,novoCPFF,novoCPFC);
				if(cv == null) {
					JOptionPane.showMessageDialog(btnPESQUISA, "Compra não foi encontrada", null, DO_NOTHING_ON_CLOSE);
				}
				else {
					comboBox.setSelectedItem(x);
					comboBox_1.setSelectedItem(CPFC);
					comboBox_2.setSelectedItem(CPFF);
					textdata.setText(cv.getData());
					texthora.setText(cv.getHora());
				}

				}
			}
		);
		btnPESQUISA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPESQUISA.setBackground(new Color(218, 232, 236));
		btnPESQUISA.setBounds(510, 225, 120, 30);
		contentPane.add(btnPESQUISA);
		
		btnEDITAR = new JButton("Editar");
		btnEDITAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(validar()) {

				String x = comboBoxP.getSelectedItem().toString();
				int y = x.indexOf("-");
				String novoChss = x.substring(y + 1);
				
				String CPFC=comboBoxP1.getSelectedItem().toString();
				int cp=CPFC.indexOf("-");
				String novoCPFC=CPFC.substring(0, cp);
				
				String CPFF=comboBoxP2.getSelectedItem().toString();
				int z=CPFF.indexOf("-");
				String novoCPFF=CPFF.substring(0, z);
				
				String HR = texthora.getText();
				
				String DATA = textdata.getText();
				
				
				compra_venda cv = new compra_venda(novoChss, novoCPFF, novoCPFC ,DATA, HR);
				cv.setVeiculo(novoChss);
				cv.setFuncionario(novoCPFF);
				cv.setCliente(novoCPFC);
				cv.setData(DATA);
				cv.setHora(HR);
				
				Compra_vendaDAO cvDAO = new Compra_vendaDAO();
				cvDAO.editar(cv);
				textdata.setText("");
				texthora.setText("");
				JOptionPane.showMessageDialog(btnEDITAR, "Venda editada com sucesso");
				}
			
			}
		});
		btnEDITAR.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEDITAR.setBackground(new Color(218, 232, 236));
		btnEDITAR.setBounds(375, 501, 120, 35);
		contentPane.add(btnEDITAR);
		
		btnEXCLUIR = new JButton("Excluir");
		btnEXCLUIR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        int resposta = JOptionPane.showOptionDialog(btnPESQUISA,
		                "Tem certeza que deseja excluir essa venda?",
		                "Confirmação de Exclusão",
		                JOptionPane.YES_NO_OPTION,
		                JOptionPane.QUESTION_MESSAGE,
		                null,
		                new Object[]{"Sim", "Não"},
		                "Não");

		        // Verificando a resposta do usuário
		        if (resposta == JOptionPane.YES_OPTION) {
		            // Código para excluir a venda
		        	String x = comboBoxP.getSelectedItem().toString();
					int y = x.indexOf("-");
					String novoChss = x.substring(y + 1);
		    		
		    		String CPFC=comboBoxP1.getSelectedItem().toString();
		    		int cp=CPFC.indexOf("-");
		    		String novoCPFC=CPFC.substring(0, cp);
		    		
		    		String CPFF=comboBoxP2.getSelectedItem().toString();
		    		int z=CPFF.indexOf("-");
		    		String novoCPFF=CPFF.substring(0, z);
		    		
		    		Compra_vendaDAO cvDAO = new Compra_vendaDAO();
		    		cvDAO.deletar(novoChss,novoCPFF,novoCPFC );
		    		textdata.setText("");
		    		texthora.setText("");
		            System.out.println("Venda excluída!");
		        } else {
		            // Código para lidar com o cancelamento da exclusão
		            System.out.println("Exclusão cancelada.");
		        }
	
			}
		});
		btnEXCLUIR.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEXCLUIR.setBackground(new Color(218, 232, 236));
		btnEXCLUIR.setBounds(505, 501, 120, 35);
		contentPane.add(btnEXCLUIR);
		
		JButton btnRELATORIO = new JButton("Visualizar");
		btnRELATORIO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SelectCV slv = new SelectCV();
				slv.setVisible(true);
			}
		});
		btnRELATORIO.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnRELATORIO.setBackground(new Color(218, 232, 236));
		btnRELATORIO.setBounds(640, 225, 120, 30);
		contentPane.add(btnRELATORIO);
		
		lblPesquisarPessoa = new JLabel("_____________________________________________________________________________________________________________________________");
		lblPesquisarPessoa.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblPesquisarPessoa.setBounds(-18, 254, 905, 20);
		contentPane.add(lblPesquisarPessoa);
		
		texthora = new JTextField();
		texthora.setFont(new Font("Tahoma", Font.PLAIN, 15));
		texthora.setBounds(70, 430, 200, 25);
		contentPane.add(texthora);
		texthora.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Veículo:");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(20, 150, 85, 20);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Cliente:");
		lblNewLabel_1_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1_1.setBounds(265, 150, 85, 20);
		contentPane.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Funcionario:");
		lblNewLabel_1_1_2.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1_2.setBounds(510, 150, 118, 20);
		contentPane.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Veículo:");
		lblNewLabel_1_1_3.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1_3.setBounds(22, 310, 85, 20);
		contentPane.add(lblNewLabel_1_1_3);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Cliente:");
		lblNewLabel_1_1_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1_1_1.setBounds(267, 310, 85, 20);
		contentPane.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_2_1 = new JLabel("Funcionario:");
		lblNewLabel_1_1_2_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1_2_1.setBounds(512, 310, 118, 20);
		contentPane.add(lblNewLabel_1_1_2_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Hora:");
		lblNewLabel_1_2.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_2.setBounds(20, 430, 85, 20);
		contentPane.add(lblNewLabel_1_2);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(4, 10, 86, 20);
		contentPane.add(btnVoltar);
		
		
		
		
		
	}

	private boolean validar() {
	    List<String> errors = new ArrayList<>();

	    // Verificação de campos vazios
	    if (textdata.getText().isEmpty() ||
	    	texthora.getText().isEmpty()) {

	        errors.add("Nenhum campo pode estar vazio.");
	    }

	    // Verificação de formato de CPF

	    // Verificação de formato de Data de Nascimento
	    if (!textdata.getText().matches("\\d{2}/\\d{2}/\\d{4}")) {
	        errors.add("Formato de Data inválido. Utilize o formato DD/MM/AAAA.");
	    }
	    // Verificação de formato de Número
	    if (!texthora.getText().matches("([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]")) {
	        errors.add("Formato de hora inválido. Utilize o formato HH:MM:SS.");
	    }
	    
	


	    
	    // Exibir mensagens de erro, se houver alguma
	    if (!errors.isEmpty()) {
	        StringBuilder errorMessage = new StringBuilder("Por favor, corrija os seguintes erros:\n");
	        for (String error : errors) {
	            errorMessage.append("- ").append(error).append("\n");
	        }
	        JOptionPane.showMessageDialog(contentPane, errorMessage.toString());
	        return false;
	    }
	    return true;
	}
}
