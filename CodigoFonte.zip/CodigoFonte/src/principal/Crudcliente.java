package principal;
import dao.ClienteDAO;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import dao.Compra_vendaDAO;
import dao.FuncionarioDAO;
import dao.PessoaDAO;
import dao.VeiculoDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;

import bean.Cliente;
import bean.funcionario;
import bean.pessoa;
import bean.veiculo;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Crudcliente extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField txtCNH;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Crudcliente frame = new Crudcliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**the 
	 * Create the frame.
	 */
	public Crudcliente() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 599);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(107, 10, 640, 82);
		contentPane.add(lblNewLabel);

		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(165, 162, 170));
		panel_1.setBounds(68, 131, 164, 45);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(0, 10, 164, 21);
		panel_1.add(comboBox_1);
		
		ClienteDAO cdao=new ClienteDAO();
		List<Cliente> clientes=cdao.listarTodos();
		for(Cliente c: clientes) {
			comboBox_1.addItem(c.getCpf() + "-" + c.getNome());
		}
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(165, 162, 170));
		panel.setBounds(10, 220, 816, 342);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		JButton btnCADASTRA = new JButton("Cadastro");
		btnCADASTRA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCADASTRA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				txtCNH = new JTextField();
				txtCNH.setBounds(99, 101, 230, 19);
				panel.add(txtCNH);
				txtCNH.setColumns(10);
				
				JLabel lblNewLabel_1 = new JLabel("CNH");
				lblNewLabel_1.setBounds(52, 86, 77, 49);
				panel.add(lblNewLabel_1);
				
				JComboBox comboBoxc = new JComboBox();
				comboBoxc.setBounds(99, 49, 230, 21);
				panel.add(comboBoxc);
				PessoaDAO pdao=new PessoaDAO();
				List<pessoa> list=pdao.listarsemc();
				for(pessoa p:list) {
					comboBoxc.addItem(p.getCpf() + "-" + p.getNome());
				}
				
				JLabel lblNewLabel_1_1 = new JLabel("Cpf de pessoa");
				lblNewLabel_1_1.setBounds(21, 35, 77, 49);
				panel.add(lblNewLabel_1_1);
				
				JButton btnNewButton = new JButton("cadastrar");
				btnNewButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(validateFields()) {
						String cpf=comboBoxc.getSelectedItem().toString();
						int indice=cpf.indexOf("-");
						String novoCPF=cpf.substring(0, indice);
						
						int CNH=Integer.parseInt(txtCNH.getText());
						
						PessoaDAO pdao=new PessoaDAO();
						pessoa p = pdao.getPessoa(novoCPF);
						Cliente c=new Cliente(novoCPF,CNH,p.getNome(),p.getRG(),p.getLogradouro(),p.getCidade(),p.getPais(),p.getEstado(),p.getData_nasc(),p.getCEP(),p.getNumero() );
						ClienteDAO cdao=new ClienteDAO();
						cdao.inserir(c);
						JOptionPane.showMessageDialog(btnCADASTRA, "Cliente adicionado(a) com sucesso");
						txtCNH.setText("");
						
						
						comboBox_1.removeAllItems();
						List<Cliente> clientes = cdao.listarTodos();
						for (Cliente cl : clientes) {
						    comboBox_1.addItem(cl.getCpf() + "-" + cl.getNome());
						}			
						}
						
					}
				});
				btnNewButton.setBounds(413, 197, 85, 21);
				panel.add(btnNewButton);

				repaint();
					}
				});
				
			
				
			
		
		btnCADASTRA.setBackground(new Color(218, 232, 236));
		btnCADASTRA.setBounds(571, 141, 120, 35);
		contentPane.add(btnCADASTRA);
		
		
		
		
		
		
		JButton btnPESQUISA = new JButton("Pesquisar");
		btnPESQUISA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 10, 796, 248);
				panel.add(scrollPane);
				table = new JTable();
				scrollPane.setViewportView(table);
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
							"Cpf", "Nome" , "CNH"
					}
				));
				
				
				
				DefaultTableModel tabela=(DefaultTableModel) table.getModel();
				String cpf=comboBox_1.getSelectedItem().toString();
				int indice=cpf.indexOf("-");
				String novoCPF=cpf.substring(0, indice);
				
				
				ClienteDAO cdao=new ClienteDAO();
				Cliente c = cdao.getCliente(novoCPF);
				
				
				String Nome = c.getNome();
				String CNH = Integer.toString(c.getCNH());
				Object[] itens=new Object[] {
						novoCPF,
						Nome,
						CNH
				};
				tabela.addRow(itens);
				
				JButton btndel = new JButton("Deletar");
				btndel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int resposta = JOptionPane.showOptionDialog(btnPESQUISA,
				                "Tem certeza que deseja excluir o cadastro desse cliente?",
				                "Confirmação de Exclusão",
				                JOptionPane.YES_NO_OPTION,
				                JOptionPane.QUESTION_MESSAGE,
				                null,
				                new Object[]{"Sim", "Não"},
				                "Não");

				        // Verificando a resposta do usuário
				        if (resposta == JOptionPane.YES_OPTION) {
				            // Código para excluir a venda
				        	String cpf=comboBox_1.getSelectedItem().toString();
							int indice=cpf.indexOf("-");
							String novoCPF=cpf.substring(0, indice);
							
							ClienteDAO cdao = new ClienteDAO();
							cdao.deletar(novoCPF);
							JOptionPane.showMessageDialog(btnCADASTRA, "Cliente removido com sucesso");
							comboBox_1.removeAllItems();
							
					        List<Cliente> clientes = cdao.listarTodos();
					        for (Cliente cl : clientes) {
					            comboBox_1.addItem(cl.getCpf() + "-" + cl.getNome());
					        }
				            System.out.println("Venda excluída!");
				        } else {
				            
				            System.out.println("Exclusão cancelada.");
				        }
						
					}
				});
				btndel.setBounds(20, 268, 85, 21);
				panel.add(btndel);
				
				JButton btnNewButton_2 = new JButton("Editar");
				panel.add(btnNewButton_2);
				btnNewButton_2.setBounds(133, 268, 85, 21);
				btnNewButton_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panel.removeAll();
						
						String cpf=comboBox_1.getSelectedItem().toString();
						int indice=cpf.indexOf("-");
						String novoCPF=cpf.substring(0, indice);
						
						ClienteDAO VeiculoDAO = new ClienteDAO();
						Cliente v = VeiculoDAO.getCliente(novoCPF);
						txtCNH = new JTextField();
						txtCNH.setBounds(99, 101, 230, 19);
						panel.add(txtCNH);
						txtCNH.setColumns(10);
						txtCNH.setText(String.valueOf(v.getCNH()));
						
						JLabel lblNewLabel_1 = new JLabel("CNH");
						lblNewLabel_1.setBounds(52, 86, 77, 49);
						panel.add(lblNewLabel_1);
			
					
						
						JButton btnNewButton = new JButton("editar");
						btnNewButton.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								if(validateFields()) {
								String cpf=comboBox_1.getSelectedItem().toString();
								int indice=cpf.indexOf("-");
								String novoCPF=cpf.substring(0, indice);
								
								int CNH=Integer.parseInt(txtCNH.getText());
								PessoaDAO pdao=new PessoaDAO();
								pessoa p = pdao.getPessoa(novoCPF);
								Cliente c=new Cliente(novoCPF,CNH,p.getNome(),p.getRG(),p.getLogradouro(),p.getCidade(),p.getPais(),p.getEstado(),p.getData_nasc(),p.getCEP(),p.getNumero() );
								c.setCNH(CNH);
								ClienteDAO cdao=new ClienteDAO();
								cdao.editar(c);
								JOptionPane.showMessageDialog(btnCADASTRA, "Cliente editado com sucesso");
								txtCNH.setText("");
								}
							}
						});
						btnNewButton.setBounds(413, 197, 85, 21);
						panel.add(btnNewButton);
						
						
						
						}
					
				});
				
				
				
				
					
				
			repaint();	
			}
			
		});
		btnPESQUISA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPESQUISA.setBackground(new Color(218, 232, 236));
		btnPESQUISA.setBounds(311, 143, 120, 30);
		contentPane.add(btnPESQUISA);
		
		
		JButton btnVisualizar = new JButton("Visualizar");
		btnVisualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 10, 796, 248);
				panel.add(scrollPane);
				table = new JTable();
				scrollPane.setViewportView(table);
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
						"Cpf", "Nome" , "CNH"
					}
				));
				ClienteDAO cdao=new ClienteDAO();
				List<Cliente> lc = cdao.listarTodos();
			
				
				DefaultTableModel tabela = (DefaultTableModel) table.getModel();
				
				for(Cliente c  : lc) {
					Object[] obj = new Object[] {
						c.getCpf(),
						c.getNome(),
						c.getCNH()
					};
					tabela.addRow(obj);
				}

			
				
			repaint();	
				
			}
		});
		btnVisualizar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVisualizar.setBackground(new Color(218, 232, 236));
		btnVisualizar.setBounds(441, 143, 120, 30);
		contentPane.add(btnVisualizar);
		
		JLabel lblNewLabel_1_1 = new JLabel("Selecione um Cliente:");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(10, 101, 260, 20);
		contentPane.add(lblNewLabel_1_1);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(10, 10, 86, 20);
		contentPane.add(btnVoltar);
		
		
		
		
	}
	private boolean validateFields() {
	    List<String> errors = new ArrayList<>();

	    // Verificação de campos vazios
	    if (txtCNH.getText().isEmpty()){
	        errors.add("Nenhum campo pode estar vazio.");
	    }

	    // Verificação de formato de CEP
	    if (!txtCNH.getText().matches("\\d{10}")) {
	        errors.add("Formato de CNH inválido. Deve conter 10 números.");
	    }
	    if (!errors.isEmpty()) {
	        StringBuilder errorMessage = new StringBuilder("Por favor, corrija os seguintes erros:\n");
	        for (String error : errors) {
	            errorMessage.append("- ").append(error).append("\n");
	        }
	        JOptionPane.showMessageDialog(contentPane, errorMessage.toString());
	        return false;
	    }

	    return true;
	}
}
