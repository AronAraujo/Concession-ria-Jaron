package principal;
import dao.FuncionarioDAO;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import dao.ClienteDAO;
import dao.Compra_vendaDAO;
import dao.PessoaDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;

import bean.Cliente;
import bean.funcionario;
import bean.pessoa;
import bean.veiculo;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Crudfunc extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnEXCLUIR;
	private JTable table;
	private JTextField txtRF;
	private JTextField textSal;
	private JTextField textdata_admi;
	private JTextField textmeta;
	private JTextField textcomi;
	private String cpf_e;
	private String fatura_e;
	private String salario_e;
	private String data_e;
	private String meta_e;
	private String comissão_e;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Crudfunc frame = new Crudfunc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Crudfunc() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 599);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(107, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(65, 150, 235, 25);
		contentPane.add(comboBox);
		FuncionarioDAO fdao=new FuncionarioDAO();
		List<funcionario> listaF=fdao.listarTodos();
		for(funcionario f:listaF) {
			comboBox.addItem(f.getCpf() + "-" + f.getNome());
		}
		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(165, 162, 170));
		panel.setBounds(10, 190, 815, 342);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		
		/////////////////////////////////////////q
		
		JButton btnCADASTRA = new JButton("Cadastrar");
		btnCADASTRA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCADASTRA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				txtRF = new JTextField();
				txtRF.setBounds(160, 110, 230, 25);
				panel.add(txtRF);
				txtRF.setColumns(10);
				textSal = new JTextField();
				textSal.setBounds(160, 145, 230, 25);
				panel.add(textSal);
				textSal.setColumns(10);
				
				JLabel lblNewLabel_2 = new JLabel("Salario Fixo:");
				lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
				lblNewLabel_2.setBounds(10, 140, 120, 30);
				panel.add(lblNewLabel_2);
				
				textdata_admi = new JTextField();
				textdata_admi.setBounds(160, 180, 230, 25);
				panel.add(textdata_admi);
				textdata_admi.setColumns(10);
				
				textmeta = new JTextField();
				textmeta.setColumns(10);
				textmeta.setBounds(160, 215, 230, 25);
				panel.add(textmeta);
				
				textcomi = new JTextField();
				textcomi.setColumns(10);
				textcomi.setBounds(160, 250, 230, 25);
				panel.add(textcomi);
				
				JLabel lblNewLabel_2_1 = new JLabel("Data Admissão:");
				lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
				lblNewLabel_2_1.setBounds(10, 175, 200, 30);
				panel.add(lblNewLabel_2_1);
				
				JLabel lblNewLabel_2_2 = new JLabel("Meta:");
				lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
				lblNewLabel_2_2.setBounds(10, 210, 200, 30);
				panel.add(lblNewLabel_2_2);
				
				JLabel lblNewLabel_2_3 = new JLabel("Comissão");
				lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
				lblNewLabel_2_3.setBounds(10, 245, 200, 30);
				panel.add(lblNewLabel_2_3);
				
				JLabel lblNewLabel_1 = new JLabel("Registro Faturamento:");
				lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
				lblNewLabel_1.setBounds(10, 80, 245, 30);
				panel.add(lblNewLabel_1);
				
			
				
				JComboBox comboBoxc = new JComboBox();
				comboBoxc.setBounds(160, 45, 230, 25);
				panel.add(comboBoxc);
				PessoaDAO pdao=new PessoaDAO();
				List<pessoa> list=pdao.listarsemf();
				for(pessoa p:list) {
					comboBoxc.addItem(p.getCpf() + "-" + p.getNome());
				}
				
				JLabel lblNewLabel_1_1 = new JLabel("Cpf de pessoa:");
				lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
				lblNewLabel_1_1.setBounds(10, 40, 200, 30);
				panel.add(lblNewLabel_1_1);
				
				JButton btnNewButton = new JButton("Cadastrar");
				btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
				btnNewButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if(validar()) {
						String cpf=comboBoxc.getSelectedItem().toString();
						int indice=cpf.indexOf("-");
						String novoCPF=cpf.substring(0, indice);
						
						double SAL=Double.parseDouble(textSal.getText());
						double RF=Double.parseDouble(txtRF.getText());
						double MT=Double.parseDouble(textmeta.getText());
						double CM=Double.parseDouble(textcomi.getText());

						
						PessoaDAO pdao=new PessoaDAO();
						pessoa p = pdao.getPessoa(novoCPF);
						funcionario c=new funcionario(novoCPF,SAL,textdata_admi.getText(),MT,RF,CM,p.getNome(),p.getRG(),p.getLogradouro(),p.getCidade(),p.getPais(),p.getEstado(),p.getData_nasc(),p.getCEP(),p.getNumero() );
						FuncionarioDAO cdao=new FuncionarioDAO();
						cdao.inserir(c);
						JOptionPane.showMessageDialog(btnNewButton, "Funcionario adicionado(a) com sucesso");
						clearFields();
						 comboBox.removeAllItems();
					        List<funcionario> clientes = cdao.listarTodos();
					        for (funcionario cl : clientes) {
					            comboBox.addItem(cl.getCpf() + "-" + cl.getNome());
					        }
						}
							
					}
				});
				btnNewButton.setBounds(560, 270, 120, 30);
				panel.add(btnNewButton);
				
				
				
				
				repaint();
					}
				});
				
			
				
			
		
		btnCADASTRA.setBackground(new Color(218, 232, 236));
		btnCADASTRA.setBounds(576, 150, 120, 30);
		contentPane.add(btnCADASTRA);
		
		
		
		
		
		
		JButton btnPESQUISA = new JButton("Pesquisar");
		btnPESQUISA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 10, 796, 248);
				panel.add(scrollPane);
				table = new JTable();
				scrollPane.setViewportView(table);
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
							"Cpf", "Nome" , "Salario Fixo", "Data de Admissão","Registro de Faturamento","Meta","Comissão"
					}
				));
				
				
				
				contentPane.repaint();
				JButton btndel = new JButton("Deletar");
				btndel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						int resposta = JOptionPane.showOptionDialog(btnPESQUISA,
				                "Tem certeza que deseja excluir o cadastro desse cliente?",
				                "Confirmação de Exclusão",
				                JOptionPane.YES_NO_OPTION,
				                JOptionPane.QUESTION_MESSAGE,
				                null,
				                new Object[]{"Sim", "Não"},
				                "Não");

				        // Verificando a resposta do usuário
				        if (resposta == JOptionPane.YES_OPTION) {
				            // Código para excluir a venda
				        	String cpf=comboBox.getSelectedItem().toString();
							int indice=cpf.indexOf("-");
							String novoCPF=cpf.substring(0, indice);
							
							FuncionarioDAO cdao = new FuncionarioDAO();
							cdao.deletar(novoCPF);	
							JOptionPane.showMessageDialog(btnCADASTRA, "Cliente excluido com sucesso");
							
							 comboBox.removeAllItems();
						        List<funcionario> clientes = cdao.listarTodos();
						        for (funcionario cl : clientes) {
						            comboBox.addItem(cl.getCpf() + "-" + cl.getNome());
						        }
				            System.out.println("Venda excluída!");
				        } else {
				            
				            System.out.println("Exclusão cancelada.");
				        }
						
					}
				});
				btndel.setBounds(20, 268, 85, 21);
				panel.add(btndel);
				
				
				
				DefaultTableModel tabela=(DefaultTableModel) table.getModel();
				String cpf=comboBox.getSelectedItem().toString();
				int indice=cpf.indexOf("-");
				String novoCPF=cpf.substring(0, indice);
				
				FuncionarioDAO cdao=new FuncionarioDAO();
				funcionario c = cdao.getFuncionario(novoCPF);
			
				String Cpf = c.getCpf();
				String Nome = c.getNome();
				String DT = c.getData_adimissao();
				String CNH = Double.toString(c.getSalario());
				String CM = Double.toString(c.getComissao());
				String MT = Double.toString(c.getMeta());
				String RF = Double.toString(c.getRegistroFaturamento());
				Object[] itens=new Object[] {
						Cpf,
						Nome,
						CNH,
						DT,
						RF,
						MT,
						CM
						
				};
				tabela.addRow(itens);
				
				JButton btnNewButton_2 = new JButton("Editar");
				panel.add(btnNewButton_2);
				btnNewButton_2.setBounds(133, 268, 85, 21);
				btnNewButton_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						int linha=table.getSelectedRow();
						String cpf_e=tabela.getValueAt(linha, 0).toString();
						String nome_e=tabela.getValueAt(linha, 1).toString();
						String salario_e=tabela.getValueAt(linha, 2).toString();
						String admissao_e=tabela.getValueAt(linha, 3).toString();
						String fatura_e=tabela.getValueAt(linha, 4).toString();
						String meta_e=tabela.getValueAt(linha, 5).toString();
						String comissa_e=tabela.getValueAt(linha, 6).toString();
						
						panel.removeAll();
						
						txtRF = new JTextField();
						txtRF.setBounds(160, 110, 230, 25);
						panel.add(txtRF);
						txtRF.setColumns(10);
						txtRF.setText(fatura_e);
						textSal = new JTextField();
						textSal.setBounds(160, 145, 230, 25);
						panel.add(textSal);
						textSal.setColumns(10);
						textSal.setText(salario_e);
						
						JLabel lblNewLabel_2 = new JLabel("Salario Fixo:");
						lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
						lblNewLabel_2.setBounds(10, 140, 120, 30);
						panel.add(lblNewLabel_2);
						
						textdata_admi = new JTextField();
						textdata_admi.setBounds(160, 180, 230, 25);
						panel.add(textdata_admi);
						textdata_admi.setColumns(10);
						textdata_admi.setText(admissao_e);
						
						textmeta = new JTextField();
						textmeta.setColumns(10);
						textmeta.setBounds(160, 215, 230, 25);
						panel.add(textmeta);
						textmeta.setText(meta_e);
						
						textcomi = new JTextField();
						textcomi.setColumns(10);
						textcomi.setBounds(160, 250, 230, 25);
						panel.add(textcomi);
						textcomi.setText(comissa_e);
						
						JLabel lblNewLabel_2_1 = new JLabel("Data Admissão:");
						lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
						lblNewLabel_2_1.setBounds(10, 175, 200, 30);
						panel.add(lblNewLabel_2_1);
						
						JLabel lblNewLabel_2_2 = new JLabel("Meta:");
						lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
						lblNewLabel_2_2.setBounds(10, 210, 200, 30);
						panel.add(lblNewLabel_2_2);
						
						JLabel lblNewLabel_2_3 = new JLabel("Comissão");
						lblNewLabel_2_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
						lblNewLabel_2_3.setBounds(10, 245, 200, 30);
						panel.add(lblNewLabel_2_3);
						
						JLabel lblNewLabel_1 = new JLabel("Registro Faturamento:");
						lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
						lblNewLabel_1.setBounds(10, 80, 245, 30);
						panel.add(lblNewLabel_1);
						
						
						JButton btnNewButton = new JButton("editar");
						btnNewButton.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								
								if(validar()) {
								
								String cpf=comboBox.getSelectedItem().toString();
								int indice=cpf.indexOf("-");
								String novoCP=cpf.substring(0, indice);
								
								double SAL=Double.parseDouble(textSal.getText());
								double RF=Double.parseDouble(txtRF.getText());
								double MT=Double.parseDouble(textmeta.getText());
								double CM=Double.parseDouble(textcomi.getText());
				
								
								PessoaDAO pdao=new PessoaDAO();
								pessoa p = pdao.getPessoa(novoCP);
								funcionario c=new funcionario(cpf_e,SAL,textdata_admi.getText(),MT,RF,CM,p.getNome(),p.getRG(),p.getLogradouro(),p.getCidade(),p.getPais(),p.getEstado(),p.getData_nasc(),p.getCEP(),p.getNumero() );
								c.setComissao(CM);
								c.setData_adimissao(textdata_admi.getText());
								c.setMeta(MT);
								c.setSalario(SAL);
								c.setRegistroFaturamento(RF);
								FuncionarioDAO cdao=new FuncionarioDAO();
								cdao.editar(c);
								JOptionPane.showMessageDialog(btnCADASTRA, "Funcionario editado com sucesso");
								clearFields();
								}
								
							}
						});
						btnNewButton.setBounds(413, 197, 85, 21);
						panel.add(btnNewButton);
						
						
						
						
					repaint();
		
					}
				});
				
			repaint();	
			}
			
		});
		btnPESQUISA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPESQUISA.setBackground(new Color(218, 232, 236));
		btnPESQUISA.setBounds(310, 150, 120, 30);
		contentPane.add(btnPESQUISA);
		
		
		JButton btnVisualizar = new JButton("Visualizar");
		btnVisualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panel.removeAll();
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(10, 10, 796, 248);
				panel.add(scrollPane);
				table = new JTable();
				scrollPane.setViewportView(table);
				table.setModel(new DefaultTableModel(
					new Object[][] {
					},
					new String[] {
							"Cpf", "Nome" , "Salario Fixo", "Data de Admissão","Registro de Faturamento","Meta","Comissão"					}
				));
				FuncionarioDAO cdao=new FuncionarioDAO();
				List<funcionario> lc = cdao.listarTodos();
			
				
				DefaultTableModel tabela = (DefaultTableModel) table.getModel();
				
				for(funcionario c  : lc) {
					Object[] obj = new Object[] {
						c.getCpf(),
						c.getNome(),
						c.getSalario(),
						c.getData_adimissao(),
						c.getRegistroFaturamento(),
						c.getMeta(),
						c.getComissao()
						
					};
					tabela.addRow(obj);
				}
				
				
			repaint();	
				
			}
		});
		btnVisualizar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVisualizar.setBackground(new Color(218, 232, 236));
		btnVisualizar.setBounds(440, 150, 120, 30);
		contentPane.add(btnVisualizar);
		
		JLabel lblNewLabel_1_1 = new JLabel("Selecione um Funcionario:");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(10, 120, 260, 20);
		contentPane.add(lblNewLabel_1_1);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(11, 10, 86, 20);
		contentPane.add(btnVoltar);
		
		
		
	}
	
	private boolean validar() {
	    List<String> errors = new ArrayList<>();

	    // Verificação de campos vazios
	    if (txtRF.getText().isEmpty() ||
	    	textSal.getText().isEmpty() ||
	    	textmeta.getText().isEmpty() ||
	        textdata_admi.getText().isEmpty() ||
	        textcomi.getText().isEmpty()) {

	        errors.add("Nenhum campo pode estar vazio.");
	    }

	    // Verificação de formato de CPF

	    // Verificação de formato de Data de Nascimento
	    if (!textdata_admi.getText().matches("\\d{2}/\\d{2}/\\d{4}")) {
	        errors.add("Formato de Data de Adimissão inválido. Utilize o formato DD/MM/AAAA.");
	    }
	    // Verificação de formato de Número
	    if (!txtRF.getText().matches("\\d+(\\.\\d+)?")) {
	        errors.add("Formato de Registro de Faturamento inválido. Deve conter apenas números.");
	    }
	    if (!textSal.getText().matches("\\d+(\\.\\d+)?")) {
	        errors.add("Formato de Salário inválido. Deve conter apenas números.");
	    }
	    if (!textmeta.getText().matches("\\d+(\\.\\d+)?")) {
	        errors.add("Formato de Meta inválido. Deve conter apenas números.");
	    }
	    if (!textcomi.getText().matches("\\d+(\\.\\d+)?")) {
	        errors.add("Formato de Comissão inválido. Deve conter apenas números.");
	    }

	    // Exibir mensagens de erro, se houver alguma
	    if (!errors.isEmpty()) {
	        StringBuilder errorMessage = new StringBuilder("Por favor, corrija os seguintes erros:\n");
	        for (String error : errors) {
	            errorMessage.append("- ").append(error).append("\n");
	        }
	        JOptionPane.showMessageDialog(contentPane, errorMessage.toString());
	        return false;
	    }
	    return true;
	}

	private void clearFields() {
		txtRF.setText("");
		textSal.setText("");
		textmeta.setText("");
		textdata_admi.setText("");
		textcomi.setText("");
	}
}
