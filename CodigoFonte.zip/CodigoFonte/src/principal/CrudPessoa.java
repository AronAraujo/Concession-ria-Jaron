package principal;



import javax.swing.JFrame;
import javax.swing.JPanel;

import dao.ClienteDAO;
import dao.Compra_vendaDAO;
import dao.FuncionarioDAO;
import dao.PessoaDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;

import bean.Cliente;
import bean.funcionario;
import bean.pessoa;

import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import com.toedter.calendar.JDateChooser;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.JFormattedTextField;
import com.toedter.calendar.JCalendar;

public class CrudPessoa extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JFormattedTextField textCPF;
	private JTextField textNOME;
	private JLabel lblNewLabel_1;
	private JLabel lblCadastroPessoa;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField textRG;
	private JLabel lblNewLabel_4;
	private JTextField textLOG;
	private JLabel lblNewLabel_5;
	private JTextField textCID;
	private JTextField textEST;
	private JTextField textPAIS;
	private JTextField textNUM;
	private JTextField textDT_NASC;
	private JTextField textCEP;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	private JLabel lblNewLabel_10;
	private JTextField textPesquisa;
	private JButton btnEDITAR;
	private JButton btnEXCLUIR;
	private Date dataNascSelecionada;
	private JTextField textdataNasc;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrudPessoa frame = new CrudPessoa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private boolean validateFields() {
	    List<String> errors = new ArrayList<>();

	    // Verificação de campos vazios
	    if (textCPF.getText().isEmpty() || textNOME.getText().isEmpty() ||
	        textRG.getText().isEmpty() || textLOG.getText().isEmpty() ||
	        textCID.getText().isEmpty() || textPAIS.getText().isEmpty() ||
	        textEST.getText().isEmpty() || textdataNasc.getText().isEmpty() ||
	        textCEP.getText().isEmpty() || textNUM.getText().isEmpty()) {

	        errors.add("Nenhum campo pode estar vazio.");
	    }
	    // Verificação de formato de CPF
	    if (!textCPF.getText().matches("\\d{11}")) {
	        errors.add("Formato de CPF inválido. Deve conter apenas 11 números.");
	    }

	    // Verificação de formato de Data de Nascimento
	    if (!textdataNasc.getText().matches("\\d{2}/\\d{2}/\\d{4}")) {
	        errors.add("Formato de Data de Nascimento inválido. Utilize o formato DD/MM/AAAA.");
	    }

	    // Verificação de formato de RG
	    if (!textRG.getText().matches("\\d+")) {
	        errors.add("Formato de RG inválido. Deve conter apenas números.");
	    }

	    // Verificação de formato de CEP
	    if (!textCEP.getText().matches("\\d{8}")) {
	        errors.add("Formato de CEP inválido. Deve conter apenas 8 números.");
	    }

	    // Verificação de formato de Estado
	    if (!textEST.getText().matches("[A-Za-z]{2}")) {
	        errors.add("Formato de Estado inválido. Deve conter apenas 2 letras.");
	    }

	    // Verificação de formato de Número
	    if (!textNUM.getText().matches("\\d+")) {
	        errors.add("Formato de Número inválido. Deve conter apenas números.");
	    }

	    // Exibir mensagens de erro, se houver alguma
	    if (!errors.isEmpty()) {
	        StringBuilder errorMessage = new StringBuilder("Por favor, corrija os seguintes erros:\n");
	        for (String error : errors) {
	            errorMessage.append("- ").append(error).append("\n");
	        }
	        JOptionPane.showMessageDialog(contentPane, errorMessage.toString());
	        return false;
	    }

	    return true;
	}
	private pessoa getPessoa(String cpf) {
		// TODO Auto-generated method stub
		return null;
	}

	private void clearFields() {
		textPesquisa.setText("");
		textNOME.setText("");
		textNUM.setText(String.valueOf(0));
		textRG.setText(String.valueOf(0));
		textLOG.setText("");
		textCID.setText("");
		textPAIS.setText("");
		textEST.setText("");
		textdataNasc.setText("");
		textCEP.setText("");
		textCPF.setText("");
	}
	/**
	 * Create the frame.
	 */
	public CrudPessoa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 599);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		textCPF = new JFormattedTextField();
		textCPF.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textCPF.setForeground(new Color(0, 0, 0));
		textCPF.setBackground(new Color(218, 232, 236));
		textCPF.setBounds(110, 290, 285, 25);
		contentPane.add(textCPF);
		textCPF.setColumns(10);
		
		textNOME = new JTextField();
		textNOME.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textNOME.setBackground(new Color(218, 232, 236));
		textNOME.setColumns(10);
		textNOME.setBounds(110, 325, 285, 25);
		contentPane.add(textNOME);
		
		lblNewLabel_1 = new JLabel("CPF:");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(20, 290, 86, 20);
		contentPane.add(lblNewLabel_1);
		
		lblCadastroPessoa = new JLabel("Cadastro de Pessoas:");
		lblCadastroPessoa.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 22));
		lblCadastroPessoa.setBounds(10, 235, 350, 44);
		contentPane.add(lblCadastroPessoa);
		
		lblNewLabel_2 = new JLabel("Nome:");
		lblNewLabel_2.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(20, 325, 86, 20);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("RG:");
		lblNewLabel_3.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(20, 360, 86, 20);
		contentPane.add(lblNewLabel_3);
		
		textRG = new JTextField();
		textRG.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textRG.setColumns(10);
		textRG.setBackground(new Color(218, 232, 236));
		textRG.setBounds(110, 360, 285, 25);
		contentPane.add(textRG);
		
		lblNewLabel_4 = new JLabel("Logradouro:");
		lblNewLabel_4.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_4.setBounds(405, 430, 118, 30);
		contentPane.add(lblNewLabel_4);
		
		textLOG = new JTextField();
		textLOG.setColumns(10);
		textLOG.setBackground(new Color(218, 232, 236));
		textLOG.setBounds(495, 454, 285, 25);
		contentPane.add(textLOG);
		
		lblNewLabel_5 = new JLabel("Cidade:");
		lblNewLabel_5.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_5.setBounds(405, 290, 86, 20);
		contentPane.add(lblNewLabel_5);
		
		textCID = new JTextField();
		textCID.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textCID.setColumns(10);
		textCID.setBackground(new Color(218, 232, 236));
		textCID.setBounds(495, 290, 285, 25);
		contentPane.add(textCID);
		
		textEST = new JTextField();
		textEST.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textEST.setColumns(10);
		textEST.setBackground(new Color(218, 232, 236));
		textEST.setBounds(495, 325, 285, 25);
		contentPane.add(textEST);
		
		textPAIS = new JTextField();
		textPAIS.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textPAIS.setColumns(10);
		textPAIS.setBackground(new Color(218, 232, 236));
		textPAIS.setBounds(495, 395, 285, 25);
		contentPane.add(textPAIS);
		
		textNUM = new JTextField();
		textNUM.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textNUM.setColumns(10);
		textNUM.setBackground(new Color(218, 232, 236));
		textNUM.setBounds(495, 254, 285, 25);
		contentPane.add(textNUM);

		textCEP = new JTextField();
		textCEP.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textCEP.setColumns(10);
		textCEP.setBackground(new Color(218, 232, 236));
		textCEP.setBounds(495, 360, 285, 25);
		contentPane.add(textCEP);
		
		lblNewLabel_6 = new JLabel("Estado:");
		lblNewLabel_6.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_6.setBounds(405, 325, 86, 20);
		contentPane.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("País:");
		lblNewLabel_7.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_7.setBounds(405, 395, 86, 20);
		contentPane.add(lblNewLabel_7);
		
		lblNewLabel_8 = new JLabel("CEP:");
		lblNewLabel_8.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_8.setBounds(405, 360, 118, 20);
		contentPane.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("Data n\r\nascimento:");
		lblNewLabel_9.setFont(new Font("Dialog", Font.PLAIN, 21));
		lblNewLabel_9.setBounds(20, 403, 177, 20);
		contentPane.add(lblNewLabel_9);
		
		lblNewLabel_10 = new JLabel("Numero:");
		lblNewLabel_10.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_10.setBounds(405, 255, 86, 20);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblPesquisarPessoa = new JLabel("Pesquisar Pessoa pelo CPF:");
		lblPesquisarPessoa.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 22));
		lblPesquisarPessoa.setBounds(10, 130, 345, 44);
		contentPane.add(lblPesquisarPessoa);
		
		textPesquisa = new JTextField();
		textPesquisa.setBackground(new Color(218, 232, 236));
		textPesquisa.setBounds(320, 145, 285, 25);
		contentPane.add(textPesquisa);
		textPesquisa.setColumns(10);
		
		JButton btnPESQUISA = new JButton("Pesquisar");
		btnPESQUISA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String textPesquisar = textPesquisa.getText();
				PessoaDAO pessoaDAO = new PessoaDAO();
				pessoa p = pessoaDAO.getPessoa(textPesquisar);
				if(p == null) {
					JOptionPane.showMessageDialog(btnPESQUISA, "Pessoa não foi encontrada", null, DO_NOTHING_ON_CLOSE);
				}
				else {
					textNOME.setText(p.getNome());
					textNUM.setText(String.valueOf(p.getNumero()));
					textRG.setText(String.valueOf(p.getRG()));
					textLOG.setText(p.getLogradouro());
					textCID.setText(p.getCidade());
					textPAIS.setText(p.getPais());
					textEST.setText(p.getEstado());
					textdataNasc.setText(p.getData_nasc());
					textCEP.setText(p.getCEP());
					textCPF.setText(p.getCpf());

				}
			}
		});
		btnPESQUISA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPESQUISA.setBackground(new Color(218, 232, 236));
		btnPESQUISA.setBounds(10, 182, 120, 30);
		contentPane.add(btnPESQUISA);
		
		btnEDITAR = new JButton("Editar");
		btnEDITAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (validateFields()) {
					String textPesquisar = textPesquisa.getText();	
					int rg=Integer.parseInt(textRG.getText());
					int num=Integer.parseInt(textNUM.getText());
					String LOG = textLOG.getText();
					String CID = textCID.getText();
					String PAIS = textPAIS.getText();
					String EST = textEST.getText();
					String DATA = textdataNasc.getText();
					String CEP = textCEP.getText();
					String NOME = textNOME.getText();
				
					pessoa p = new pessoa(textPesquisar, LOG, rg, CID, PAIS, EST, DATA, CEP, NOME, num);
					p.setCpf(textPesquisar);
					p.setCEP(CEP);
					p.setCidade(CID);
					p.setData_nasc(DATA);
					p.setEstado(EST);
					p.setLogradouro(LOG);
					p.setNome(NOME);
					p.setNumero(num);
					p.setPais(PAIS);
					p.setRG(rg);
				
					PessoaDAO pessoaDAO = new PessoaDAO();
					pessoaDAO.editar(p);
				
					JOptionPane.showMessageDialog(btnEDITAR, textNOME.getText() + " Editado(a) com sucesso");
					clearFields();
			}
			
			}
		});
		btnEDITAR.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEDITAR.setBackground(new Color(218, 232, 236));
		btnEDITAR.setBounds(530, 500, 120, 35);
		contentPane.add(btnEDITAR);
		

		btnEXCLUIR = new JButton("Excluir");
		btnEXCLUIR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int resposta = JOptionPane.showOptionDialog(btnPESQUISA,
		                "Tem certeza que deseja excluir essa Pessoa?",
		                "Confirmação de Exclusão",
		                JOptionPane.YES_NO_OPTION,
		                JOptionPane.QUESTION_MESSAGE,
		                null,
		                new Object[]{"Sim", "Não"},
		                "Não");

		        // Verificando a resposta do usuário
		        if (resposta == JOptionPane.YES_OPTION) {
		            // Código para excluir a venda
		        	String Cpf = textPesquisa.getText();
					PessoaDAO pessoaDAO = new PessoaDAO();
					pessoaDAO.deletar(Cpf);
					textPesquisa.setText("");
					textNOME.setText("");
					textNUM.setText(String.valueOf(0));
					textRG.setText(String.valueOf(0));
					textLOG.setText("");
					textCID.setText("");
					textPAIS.setText("");
					textEST.setText("");
					textdataNasc.setText("");
					textCEP.setText("");
					textCPF.setText("");
		            System.out.println("Venda excluída!");
		        } else {
		            
		            System.out.println("Exclusão cancelada.");
		        }
				
			}
		});
		btnEXCLUIR.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEXCLUIR.setBackground(new Color(218, 232, 236));
		btnEXCLUIR.setBounds(660, 500, 120, 35);
		contentPane.add(btnEXCLUIR);
		
		JButton btnRELATORIO = new JButton("Visualisar");
		btnRELATORIO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SelectPessoa slp = new SelectPessoa();
				slp.setVisible(true);
			}
		});
		btnRELATORIO.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnRELATORIO.setBackground(new Color(218, 232, 236));
		btnRELATORIO.setBounds(140, 182, 120, 30);
		contentPane.add(btnRELATORIO);
		
		JLabel lblPesquisarPessoa_1 = new JLabel("_____________________________________________________________________________________________________________________________");
		lblPesquisarPessoa_1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblPesquisarPessoa_1.setBounds(0, 222, 905, 20);
		contentPane.add(lblPesquisarPessoa_1);
		
		textdataNasc = new JTextField();
		textdataNasc.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textdataNasc.setColumns(10);
		textdataNasc.setBackground(new Color(218, 232, 236));
		textdataNasc.setBounds(100, 427, 285, 25);
		contentPane.add(textdataNasc);
		
		JButton btnCliente = new JButton("Cliente");
		btnCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf=textCPF.getText();
				PessoaDAO pessoaDAO = new PessoaDAO();
				pessoa pe = pessoaDAO.getPessoa(cpf);
				if(pe == null) {
					if (validateFields()) {
						int rg=Integer.parseInt(textRG.getText());
						int num=Integer.parseInt(textNUM.getText());
						pessoa p=new pessoa(cpf, textNOME.getText(), rg, textLOG.getText(),textCID.getText(), textPAIS.getText(), textEST.getText(), textdataNasc.getText(),textCEP.getText(),num);
						PessoaDAO pdao=new PessoaDAO();
						pdao.inserir(p);
						JOptionPane.showMessageDialog(btnCliente, textNOME.getText() + "adicionado(a) com sucesso");
						clearFields();
						Crudcliente crc = new Crudcliente();
						crc.setVisible(true);
						}
				}else{
					Crudcliente crc = new Crudcliente();
					crc.setVisible(true);
				}
				
			}
		});
		btnCliente.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCliente.setBackground(new Color(218, 232, 236));
		btnCliente.setBounds(62, 502, 120, 35);
		contentPane.add(btnCliente);
		
		JButton btnVendedor = new JButton("Vendedor");
		btnVendedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf=textCPF.getText();
				PessoaDAO pessoaDAO = new PessoaDAO();
				pessoa pe = pessoaDAO.getPessoa(cpf);
				if(pe == null) {
					if (validateFields()) {
						int rg=Integer.parseInt(textRG.getText());
						int num=Integer.parseInt(textNUM.getText());
						pessoa p=new pessoa(cpf, textNOME.getText(), rg, textLOG.getText(),textCID.getText(), textPAIS.getText(), textEST.getText(), textdataNasc.getText(),textCEP.getText(),num);
						PessoaDAO pdao=new PessoaDAO();
						pdao.inserir(p);
						JOptionPane.showMessageDialog(btnVendedor, textNOME.getText() + "adicionado(a) com sucesso");
						clearFields();
						Crudfunc crf = new Crudfunc();
						crf.setVisible(true);}
				}else{
					Crudfunc crf = new Crudfunc();
					crf.setVisible(true);
				}
				
				
			}
		});
		btnVendedor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVendedor.setBackground(new Color(218, 232, 236));
		btnVendedor.setBounds(192, 502, 120, 35);
		contentPane.add(btnVendedor);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(10, 10, 86, 20);
		contentPane.add(btnVoltar);
		
	}
}
