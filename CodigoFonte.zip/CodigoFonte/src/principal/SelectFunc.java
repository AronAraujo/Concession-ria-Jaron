package principal;

import java.awt.Font;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Cliente;
import bean.funcionario;
import bean.pessoa;

import javax.swing.JScrollPane;

import dao.ClienteDAO;
import dao.FuncionarioDAO;
import dao.PessoaDAO;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class SelectFunc extends JFrame {
	
	private void preencheTabela(){
		FuncionarioDAO cdao=new FuncionarioDAO();
		String Nome = txtNome.getText();
		List<funcionario> lc = cdao.listarTodosN(Nome);
		
		
		DefaultTableModel tabelaPessoa = (DefaultTableModel) tblpessoas.getModel();
		tabelaPessoa.setNumRows(0);
		
		for(funcionario c  : lc) {
			Object[] obj = new Object[] {
				c.getCpf(),
				c.getNome(),
				c.getSalario(),
				c.getData_adimissao(),
				c.getRegistroFaturamento(),
				c.getMeta(),
				c.getComissao()
				
			};
			tabelaPessoa.addRow(obj);
		}
	}
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblpessoas;
	private JScrollPane scrollPane;
	private JTextField txtNome;
	private JButton btnVoltar;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SelectFunc frame = new SelectFunc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SelectFunc() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 853, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));
		contentPane.setForeground(new Color(165, 162, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 231, 839, 171);
		contentPane.add(scrollPane);
		
		tblpessoas = new JTable();
		tblpessoas.setBorder(UIManager.getBorder("RadioButton.border"));
		tblpessoas.setForeground(new Color(0, 0, 0));
		tblpessoas.setToolTipText("");
		tblpessoas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblpessoas);
		tblpessoas.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"Cpf", "Nome" , "Salario Fixo", "Data de Admissão","Registro de Faturamento","Meta","Comissão"			
			}
		));
		
		JLabel lblRelatrioDePessoas = new JLabel(" Visualizar Funcionários:");
		lblRelatrioDePessoas.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblRelatrioDePessoas.setBounds(0, 188, 220, 44);
		contentPane.add(lblRelatrioDePessoas);
		
		JLabel lblFiltrarPorNome = new JLabel("Filtrar por nome:");
		lblFiltrarPorNome.setFont(new Font("Dialog", Font.PLAIN, 23));
		lblFiltrarPorNome.setBounds(163, 115, 220, 44);
		contentPane.add(lblFiltrarPorNome);
		
		txtNome = new JTextField();
		txtNome.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				preencheTabela();
			}
		});
		txtNome.setFont(new Font("Dialog", Font.PLAIN, 23));
		txtNome.setBounds(331, 127, 320, 30);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(10, 10, 86, 20);
		contentPane.add(btnVoltar);
		
		preencheTabela();
	}
}
