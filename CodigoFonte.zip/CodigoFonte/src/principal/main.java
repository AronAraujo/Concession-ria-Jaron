package principal;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;

public class main extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnVEICULO;
	private JButton btnVENDA;
	private JButton btnPESSOA;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 599);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		btnPESSOA = new JButton("Pessoa\r\n");
		btnPESSOA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPESSOA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					CrudPessoa crp = new CrudPessoa();
					crp.setVisible(true);
					};
				;
				
			}
		);
		btnPESSOA.setBackground(new Color(218, 232, 236));
		btnPESSOA.setBounds(10, 200, 160, 50);
		contentPane.add(btnPESSOA);
		
		btnVEICULO = new JButton("Veículo");
		btnVEICULO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrudVeiculo crv = new CrudVeiculo();
				crv.setVisible(true);
			}
		});
		btnVEICULO.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVEICULO.setBackground(new Color(218, 232, 236));
		btnVEICULO.setBounds(10, 260, 160, 50);
		contentPane.add(btnVEICULO);
		
		btnVENDA = new JButton("Venda");
		btnVENDA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CrudCV crcv = new CrudCV();
				crcv.setVisible(true);
			}
		});
		btnVENDA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVENDA.setBackground(new Color(218, 232, 236));
		btnVENDA.setBounds(10, 321, 160, 50);
		contentPane.add(btnVENDA);
		
		JButton btnRELATORIO = new JButton("Relatório");
		btnRELATORIO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Relatorio Rlt = new Relatorio();
				Rlt.setVisible(true);
			}
		});
		btnRELATORIO.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnRELATORIO.setBackground(new Color(218, 232, 236));
		btnRELATORIO.setBounds(666, 502, 160, 50);
		contentPane.add(btnRELATORIO);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setIcon(new ImageIcon(main.class.getResource("/fotos/esse.png")));
		lblNewLabel_1.setBounds(0, 0, 836, 562);
		contentPane.add(lblNewLabel_1);
	}
}
