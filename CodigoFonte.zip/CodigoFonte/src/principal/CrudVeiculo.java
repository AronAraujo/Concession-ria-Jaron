package principal;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import dao.PessoaDAO;
import dao.VeiculoDAO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;

import bean.veiculo;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;
import java.util.List;
import java.util.ArrayList;
public class CrudVeiculo extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JFormattedTextField textChassi;
	private JTextField textMarca;
	private JLabel lblNewLabel_1;
	private JLabel lblCadastroVeiculo;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JTextField textValor;
	private JLabel lblNewLabel_5;
	private JTextField textCor;
	private JTextField textMod;
	private JTextField textPla;
	private JTextField textAno;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_10;
	private JTextField textPesquisa;
	private JButton btnEDITAR;
	private JButton btnEXCLUIR;
	private JLabel lblPesquisarPessoa;
	private JButton btnVoltar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrudVeiculo frame = new CrudVeiculo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private boolean validateFields() {
		List<String> errors = new ArrayList<>();

	    if (textChassi.getText().length() != 17) {
	        errors.add("Formato de Chassi incorreto (deve ter 17 caracteres).");
	    }

	    if (textAno.getText().length() != 4) {
	        errors.add("Formato de Ano incorreto (deve ter 4 números).");
	    }

	    if (textPla.getText().length() != 8) {
	        errors.add("Formato de Placa incorreto (deve ter 8 caracteres).");
	    }

	    if (!isNumeric(textValor.getText())) {
	        errors.add("Valor não é um número válido.");
	    }

	    if (textCor.getText().isEmpty()) {
	        errors.add("Campo 'Cor' não pode estar vazio.");
	    }

	    if (textMod.getText().isEmpty()) {
	        errors.add("Campo 'Modelo' não pode estar vazio.");
	    }

	    if (textMarca.getText().isEmpty()) {
	        errors.add("Campo 'Marca' não pode estar vazio.");
	    }

	    if (textAno.getText().isEmpty()) {
	        errors.add("Campo 'Ano' não pode estar vazio.");
	    }

	    if (textPla.getText().isEmpty()) {
	        errors.add("Campo 'Placa' não pode estar vazio.");
	    }

	    if (textChassi.getText().isEmpty()) {
	        errors.add("Campo 'Chassi' não pode estar vazio.");
	    }

	    // Verificação de formato da Placa
	    String placaRegex = "[A-Z]{3}-[0-9]{4}";
	    if (!textPla.getText().matches(placaRegex)) {
	        errors.add("Formato inválido para a Placa. Utilize o formato AAA-1234.");
	    }

	    // Exibir mensagens de erro, se houver alguma
	    if (!errors.isEmpty()) {
	        StringBuilder errorMessage = new StringBuilder("Por favor, corrija os seguintes erros:\n");
	        for (String error : errors) {
	            errorMessage.append("- ").append(error).append("\n");
	        }
	        JOptionPane.showMessageDialog(contentPane, errorMessage.toString());
	        return false;
	    }

	    return true;
	}

	// Método para verificar se uma string é numérica
	private boolean isNumeric(String str) {
	    try {
	        Double.parseDouble(str);
	        return true;
	    } catch (NumberFormatException e) {
	        return false;
	    }
	}

	// Método para limpar os campos
	private void clearFields() {
	    textPesquisa.setText("");
	    textMarca.setText("");
	    textPla.setText("");
	    textValor.setText("0");
	    textCor.setText("");
	    textMod.setText("");
	    textAno.setText("");
	    textChassi.setText("");
	}

	/**
	 * Create the frame.
	 */
	public CrudVeiculo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 850, 599);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setToolTipText("");
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		JButton btnCADASTRA = new JButton("Cadastrar");
		btnCADASTRA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCADASTRA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VeiculoDAO vdao = new VeiculoDAO();
				if(vdao.verificar(textChassi.getText())) {
					JOptionPane.showMessageDialog(contentPane, "Veiculo ja cadastrado");
				}else {
					if (validateFields()) {
			            double valor = Double.parseDouble(textValor.getText());
			            veiculo v = new veiculo(textChassi.getText(), textCor.getText(), textMod.getText(),
			                                    textMarca.getText(), textPla.getText(), textAno.getText(), valor);
			            
			            vdao.inserir(v);
			            JOptionPane.showMessageDialog(btnCADASTRA, textMod.getText() + " adicionado(a) com sucesso");
			            clearFields(); // Método para limpar os campos
			        }
				}
				
			}
		});
		btnCADASTRA.setBackground(new Color(218, 232, 236));
		btnCADASTRA.setBounds(245, 501, 120, 35);
		contentPane.add(btnCADASTRA);
		
		textChassi = new JFormattedTextField();
		textChassi.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textChassi.setForeground(new Color(0, 0, 0));
		textChassi.setBackground(new Color(218, 232, 236));
		textChassi.setBounds(110, 290, 285, 25);
		contentPane.add(textChassi);
		textChassi.setColumns(10);
		
		textMarca =  new JTextField();
		textMarca.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textMarca.setBackground(new Color(218, 232, 236));
		textMarca.setColumns(10);
		textMarca.setBounds(110, 325, 285, 25);
		contentPane.add(textMarca);
		
		lblNewLabel_1 = new JLabel("Chassi:");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(20, 293, 85, 20);
		contentPane.add(lblNewLabel_1);
		
		lblCadastroVeiculo = new JLabel("Cadastro de Veiculos:");
		lblCadastroVeiculo.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 22));
		lblCadastroVeiculo.setBounds(10, 235, 332, 44);
		contentPane.add(lblCadastroVeiculo);
		
		lblNewLabel_2 = new JLabel("Marca:");
		lblNewLabel_2.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(20, 326, 86, 20);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Valor:");
		lblNewLabel_3.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(20, 396, 86, 20);
		contentPane.add(lblNewLabel_3);
		
		textValor = new JTextField();
		textValor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textValor.setColumns(10);
		textValor.setBackground(new Color(218, 232, 236));
		textValor.setBounds(110, 395, 285, 25);
		contentPane.add(textValor);
		
		lblNewLabel_5 = new JLabel("Cor:");
		lblNewLabel_5.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_5.setBounds(410, 293, 85, 20);
		contentPane.add(lblNewLabel_5);
		
		textCor = new JTextField();
		textCor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textCor.setColumns(10);
		textCor.setBackground(new Color(218, 232, 236));
		textCor.setBounds(500, 290, 285, 25);
		contentPane.add(textCor);
		
		textMod = new JTextField();
		textMod.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textMod.setColumns(10);
		textMod.setBackground(new Color(218, 232, 236));
		textMod.setBounds(500, 325, 285, 25);
		contentPane.add(textMod);
		
		textPla = new JTextField();
		textPla.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textPla.setColumns(10);
		textPla.setBackground(new Color(218, 232, 236));
		textPla.setBounds(110, 360, 285, 25);
		contentPane.add(textPla);
		
		textAno = new JTextField();
		textAno.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textAno.setColumns(10);
		textAno.setBackground(new Color(218, 232, 236));
		textAno.setBounds(500, 360, 285, 25);
		contentPane.add(textAno);
		
		lblNewLabel_6 = new JLabel("Modelo:");
		lblNewLabel_6.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_6.setBounds(410, 326, 86, 20);
		contentPane.add(lblNewLabel_6);
		
		lblNewLabel_8 = new JLabel("Ano:");
		lblNewLabel_8.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_8.setBounds(410, 361, 118, 20);
		contentPane.add(lblNewLabel_8);
		
		lblNewLabel_10 = new JLabel("Placa:");
		lblNewLabel_10.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_10.setBounds(20, 361, 86, 20);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblPesquisarVeiculo = new JLabel("Pesquisar Veiculo pelo Chassi:");
		lblPesquisarVeiculo.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 22));
		lblPesquisarVeiculo.setBounds(10, 130, 345, 44);
		contentPane.add(lblPesquisarVeiculo);
		
		textPesquisa = new JTextField();
		textPesquisa.setBackground(new Color(218, 232, 236));
		textPesquisa.setBounds(354, 145, 285, 25);
		contentPane.add(textPesquisa);
		textPesquisa.setColumns(10);
		
		JButton btnPESQUISA = new JButton("Pesquisar");
		btnPESQUISA.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String textPesquisar = textPesquisa.getText();
				VeiculoDAO VeiculoDAO = new VeiculoDAO();
				veiculo v = VeiculoDAO.getVeiculo(textPesquisar);
				if(v == null) {
					JOptionPane.showMessageDialog(btnPESQUISA, "Veiculo não foi encontrado", null, DO_NOTHING_ON_CLOSE);
				}
				else {
					textMarca.setText(v.getMarca());
					textMod.setText(v.getModelo());
					textValor.setText(String.valueOf(v.getValor()));
					textCor.setText(v.getCor());
					textPla.setText(v.getPlaca());
					textAno.setText(v.getAno());
					textChassi.setText(v.getChassi());

				}
			}
		});
		btnPESQUISA.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPESQUISA.setBackground(new Color(218, 232, 236));
		btnPESQUISA.setBounds(10, 182, 120, 30);
		contentPane.add(btnPESQUISA);
		
		btnEDITAR = new JButton("Editar");
		btnEDITAR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (validateFields()) {
		            String textPesquisar = textPesquisa.getText();
		            double valor = Double.parseDouble(textValor.getText());
		            String Pla = textPla.getText();
		            String Cor = textCor.getText();
		            String Mod = textMod.getText();
		            String Ano = textAno.getText();
		            String Marca = textMarca.getText();

		            veiculo v = new veiculo(textPesquisar, Pla, Cor, Mod, Ano, Marca, valor);
		            v.setChassi(textPesquisar);
		            v.setMarca(Marca);
		            v.setAno(Ano);
		            v.setModelo(Mod);
		            v.setCor(Cor);
		            v.setPlaca(Pla);
		            v.setValor(valor);

		            VeiculoDAO veiculoDAO = new VeiculoDAO();
		            veiculoDAO.editar(v);
		            JOptionPane.showMessageDialog(btnEDITAR, textMod.getText() + " Editado(a) com sucesso");
		            clearFields();
		        }
				

				
			
			}
		});
		btnEDITAR.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEDITAR.setBackground(new Color(218, 232, 236));
		btnEDITAR.setBounds(375, 501, 120, 35);
		contentPane.add(btnEDITAR);
		

		btnEXCLUIR = new JButton("Excluir");
		btnEXCLUIR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int resposta = JOptionPane.showOptionDialog(btnPESQUISA,
		                "Tem certeza que deseja excluir esse Veiculo?",
		                "Confirmação de Exclusão",
		                JOptionPane.YES_NO_OPTION,
		                JOptionPane.QUESTION_MESSAGE,
		                null,
		                new Object[]{"Sim", "Não"},
		                "Não");

		        // Verificando a resposta do usuário
		        if (resposta == JOptionPane.YES_OPTION) {
		            // Código para excluir a venda
		        	String Chassi = textPesquisa.getText();
					VeiculoDAO veiculoDAO = new VeiculoDAO();
					veiculoDAO.deletar(Chassi);
					textPesquisa.setText("");
					textMarca.setText("");
					textPla.setText(String.valueOf(0));
					textValor.setText(String.valueOf(0));
					textCor.setText("");
					textMod.setText("");
					textAno.setText("");
					textChassi.setText("");
		            System.out.println("Venda excluída!");
		        } else {
		            
		            System.out.println("Exclusão cancelada.");
		        }
				
			}
		});
		btnEXCLUIR.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnEXCLUIR.setBackground(new Color(218, 232, 236));
		btnEXCLUIR.setBounds(505, 501, 120, 35);
		contentPane.add(btnEXCLUIR);
		
		JButton btnRELATORIO = new JButton("Visualizar");
		btnRELATORIO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SelectVeiculo slv = new SelectVeiculo();
				slv.setVisible(true);
			}
		});
		btnRELATORIO.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnRELATORIO.setBackground(new Color(218, 232, 236));
		btnRELATORIO.setBounds(140, 182, 120, 30);
		contentPane.add(btnRELATORIO);
		
		lblPesquisarPessoa = new JLabel("_____________________________________________________________________________________________________________________________");
		lblPesquisarPessoa.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblPesquisarPessoa.setBounds(0, 222, 905, 20);
		contentPane.add(lblPesquisarPessoa);
		
		btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(4, 10, 86, 20);
		contentPane.add(btnVoltar);
	}
	
	
}
