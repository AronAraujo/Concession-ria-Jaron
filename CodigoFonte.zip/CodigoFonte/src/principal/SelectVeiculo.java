package principal;

import java.awt.Font;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.veiculo;

import javax.swing.JScrollPane;
import dao.VeiculoDAO;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class SelectVeiculo extends JFrame {
	
	private void preencheTabela(){
		VeiculoDAO veiculoDAO = new VeiculoDAO();
		String placa = textField.getText();
		List<veiculo> ListaVeiculo = veiculoDAO.listar(placa);
		
		DefaultTableModel tabelaVeiculo = (DefaultTableModel) tblveiculos.getModel();
		tabelaVeiculo.setNumRows(0);
		for(veiculo v : ListaVeiculo) {
			Object[] obj = new Object[] {
				v.getChassi(),
				v.getPlaca(),
				v.getModelo(),
				v.getMarca(),
				v.getAno(),
				v.getCor(),
				v.getValor(),
			};
			tabelaVeiculo.addRow(obj);
		}
	}
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblveiculos;
	private JScrollPane scrollPane;
	private JLabel lblPlaca;
	private JTextField textField;
	private JButton btnVoltar;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SelectVeiculo frame = new SelectVeiculo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SelectVeiculo() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 853, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));
		contentPane.setForeground(new Color(165, 162, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(74, 218, 690, 171);
		contentPane.add(scrollPane);
		
		tblveiculos = new JTable();
		tblveiculos.setBorder(UIManager.getBorder("RadioButton.border"));
		tblveiculos.setForeground(new Color(0, 0, 0));
		tblveiculos.setToolTipText("");
		tblveiculos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblveiculos);
		tblveiculos.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Chassi","Placa", "Modelo", "Marca", "Ano", "Cor", "Valor"
			}
		));
		
		JLabel lblRelatrioDeVeiculos = new JLabel("Relatório de Veiculos:");
		lblRelatrioDeVeiculos.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblRelatrioDeVeiculos.setBounds(10, 178, 220, 44);
		contentPane.add(lblRelatrioDeVeiculos);
		
		lblPlaca = new JLabel("Filtrar por placa:");
		lblPlaca.setFont(new Font("Dialog", Font.PLAIN, 23));
		lblPlaca.setBounds(163, 115, 220, 44);
		contentPane.add(lblPlaca);
		
		textField = new JTextField();
		textField.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				preencheTabela();
			}
		});
		textField.setBounds(331, 127, 320, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(10, 10, 86, 20);
		contentPane.add(btnVoltar);
		preencheTabela();
	}
}
