package principal;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.Cliente;
import bean.ClienteMaisCompras;
import bean.funcionario;
import bean.pessoa;

import javax.swing.JScrollPane;

import dao.ClienteDAO;
import dao.FuncionarioDAO;

import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;


public class Rcqmc extends JFrame {
	
private void preencheTabela(){
		
	ClienteDAO clienteDAO = new ClienteDAO();
	String Nome = txtCliente.getText();
	List<ClienteMaisCompras> Lista = clienteDAO.listarClientesMaisCompras(Nome);
	
	DefaultTableModel tabelaPessoa = (DefaultTableModel) tblpessoas.getModel();
	tabelaPessoa.setNumRows(0);
	for(ClienteMaisCompras c : Lista) {
		Object[] obj = new Object[] {
			c.getCpfCliente(),
			c.getNomeCliente(),
			c.getCnhCliente(),
			c.getTotalCompras()
		};
		tabelaPessoa.addRow(obj);
	}
		
	}
	
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblpessoas;
	private JScrollPane scrollPane;
	private JTextField txtCliente;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rcqmc frame = new Rcqmc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Rcqmc() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 853, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));
		contentPane.setForeground(new Color(165, 162, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(32, 253, 768, 171);
		contentPane.add(scrollPane);
		
		tblpessoas = new JTable();
		tblpessoas.setBorder(UIManager.getBorder("RadioButton.border"));
		tblpessoas.setForeground(new Color(0, 0, 0));
		tblpessoas.setToolTipText("");
		tblpessoas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblpessoas);
		tblpessoas.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Cpf","Nome", "CNH", "Total de Compras"
			}
		));
		
		JLabel lblRelatrioDePessoas = new JLabel("Relatório de Clientes que mais compraram:");
		lblRelatrioDePessoas.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblRelatrioDePessoas.setBounds(10, 199, 354, 44);
		contentPane.add(lblRelatrioDePessoas);
		
		JLabel lblNewLabel_1 = new JLabel("Opções do Relatório:");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(100, 116, 214, 19);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String OpSlct = comboBox.getSelectedItem().toString();
				if(OpSlct == "Carro mais caro") {
					Rcmc Opcmc = new Rcmc();
					Opcmc.setVisible(true);
					dispose();
				}else if(OpSlct == "Carro mais vendido") {
					Rcmv Opcmv= new Rcmv();
					Opcmv.setVisible(true);
					dispose();
				}else if(OpSlct == "Funcionário que mais vendeu") {
					Rfqmv Opfqmv = new Rfqmv();
					Opfqmv.setVisible(true);
					dispose();
				}else if(OpSlct == "Venda mais cara") {
					Rvmc Opvmc = new Rvmc();
					Opvmc.setVisible(true);
					dispose();
				}else if(OpSlct == "Carro mais atual") {
					Rcma Opcma = new Rcma();
					Opcma.setVisible(true);
					dispose();
				}else if(OpSlct == "") {
					JOptionPane.showMessageDialog( comboBox, "Opçõa não é valida", null, DO_NOTHING_ON_CLOSE);
				}
			}
		});
		
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Carro mais caro", "Carro mais vendido", "Carro mais atual", "Funcionário que mais vendeu", "Venda mais cara"}));
		comboBox.setBounds(309, 110, 321, 31);
		contentPane.add(comboBox);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main m = new main();
				m.setVisible(true);
				dispose();
			}
		});
		
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(10, 10, 86, 20);
		contentPane.add(btnVoltar);
		txtCliente = new JTextField();
		txtCliente.setColumns(10);
		txtCliente.setBounds(309, 169, 320, 30);
		contentPane.add(txtCliente);

		txtCliente.addCaretListener(new CaretListener() {
		    public void caretUpdate(CaretEvent e) {
		        preencheTabela();
		    }
		});

		
		
		JLabel lblNewLabel_1_1 = new JLabel("Buscar por Nome:");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(100, 170, 214, 19);
		contentPane.add(lblNewLabel_1_1);
		preencheTabela();
	}
}
