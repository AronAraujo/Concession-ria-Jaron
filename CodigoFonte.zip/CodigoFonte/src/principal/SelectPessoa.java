package principal;

import java.awt.Font;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.pessoa;

import javax.swing.JScrollPane;
import dao.PessoaDAO;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class SelectPessoa extends JFrame {
	
	private void preencheTabela(){
		PessoaDAO pessoaDAO = new PessoaDAO();
		String Nome = txtNome.getText();
		List<pessoa> ListaPessoa = pessoaDAO.listar(Nome);
		
		DefaultTableModel tabelaPessoa = (DefaultTableModel) tblpessoas.getModel();
		tabelaPessoa.setNumRows(0);
		for(pessoa p : ListaPessoa) {
			Object[] obj = new Object[] {
				p.getCpf(),
				p.getNome(),
				p.getRG(),
				p.getData_nasc(),
				p.getCidade(),
				p.getEstado(),
				p.getPais(),
				p.getLogradouro(),
				p.getNumero(),
				p.getCEP(),
			};
			tabelaPessoa.addRow(obj);
		}
	}
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblpessoas;
	private JScrollPane scrollPane;
	private JTextField txtNome;
	private JButton btnVoltar;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SelectPessoa frame = new SelectPessoa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SelectPessoa() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 853, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));
		contentPane.setForeground(new Color(165, 162, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 231, 839, 171);
		contentPane.add(scrollPane);
		
		tblpessoas = new JTable();
		tblpessoas.setBorder(UIManager.getBorder("RadioButton.border"));
		tblpessoas.setForeground(new Color(0, 0, 0));
		tblpessoas.setToolTipText("");
		tblpessoas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblpessoas);
		tblpessoas.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Cpf", "Nome", "RG","Nascimento",  "Cidade","Estado",  "Pais","Logradouro", "Num","CEP"
			}
		));
		
		JLabel lblRelatrioDePessoas = new JLabel(" Visualizar Pessoas:");
		lblRelatrioDePessoas.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblRelatrioDePessoas.setBounds(0, 188, 220, 44);
		contentPane.add(lblRelatrioDePessoas);
		
		JLabel lblFiltrarPorNome = new JLabel("Filtrar por nome:");
		lblFiltrarPorNome.setFont(new Font("Dialog", Font.PLAIN, 23));
		lblFiltrarPorNome.setBounds(163, 115, 220, 44);
		contentPane.add(lblFiltrarPorNome);
		
		txtNome = new JTextField();
		txtNome.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				preencheTabela();
			}
		});
		txtNome.setFont(new Font("Dialog", Font.PLAIN, 23));
		txtNome.setBounds(331, 127, 320, 30);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(10, 10, 86, 20);
		contentPane.add(btnVoltar);
		
		JButton btnCli = new JButton("Visualisar C");
		btnCli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SelectCliente sc = new SelectCliente();
				sc.setVisible(true);
			}
		});
		btnCli.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnCli.setBackground(new Color(218, 232, 236));
		btnCli.setBounds(704, 191, 135, 30);
		contentPane.add(btnCli);
		
		JButton btnVisualisarF = new JButton("Visualisar F");
		btnVisualisarF.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SelectFunc sf = new SelectFunc();
				sf.setVisible(true);
			}
		});
		btnVisualisarF.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnVisualisarF.setBackground(new Color(218, 232, 236));
		btnVisualisarF.setBounds(559, 191, 135, 30);
		contentPane.add(btnVisualisarF);
		
		preencheTabela();
	}
}
