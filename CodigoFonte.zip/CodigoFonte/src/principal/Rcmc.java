package principal;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.veiculo;

import javax.swing.JScrollPane;
import dao.VeiculoDAO;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.event.CaretListener;
import javax.swing.event.CaretEvent;


public class Rcmc extends JFrame {
	
	
	

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tblveiculos;
	private JScrollPane scrollPane;
	private JTextField textField;
	private JTextField textField_1;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Rcmc frame = new Rcmc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static double convertStringToDouble(String stringValue) {
        try {
            // Tenta converter a string para double
            return Double.parseDouble(stringValue);
        } catch (NumberFormatException e) {
            // Se ocorrer uma exceção, trata o caso da string vazia
            if (stringValue.isEmpty()) {
                System.out.println("A string está vazia. Valor double padrão: 0.0");
                return 0.0;
            } else {
                // Se a string não estiver vazia, imprime o erro e retorna um valor padrão (pode ser ajustado conforme necessário)
                System.out.println("Erro ao converter a string para double: " + e.getMessage());
                return Double.NaN; // Valor padrão para indicar que houve um erro
            }
        }
    }
	private void preencheTabela() {
    	String valorTexto = textField.getText().trim();
        double doubleValue = convertStringToDouble(valorTexto);
        VeiculoDAO veiculoDAO = new VeiculoDAO();
        List<veiculo> ListaVeiculo = veiculoDAO.listarVeiculosPorValor(doubleValue);

        DefaultTableModel tabelaVeiculo = (DefaultTableModel) tblveiculos.getModel();
        tabelaVeiculo.setNumRows(0);

        for (veiculo v : ListaVeiculo) {
            Object[] obj = new Object[] {
                    v.getChassi(),
                    v.getModelo(),
                    v.getMarca(),
                    v.getPlaca(),
                    v.getAno(),
                    v.getCor(),
                    v.getValor(),
            };
            tabelaVeiculo.addRow(obj);
        }
        
    }
	/**
	 * Create the frame.
	 */
	public Rcmc() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 853, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));
		contentPane.setForeground(new Color(165, 162, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(74, 249, 690, 171);
		contentPane.add(scrollPane);
		
		tblveiculos = new JTable();
		tblveiculos.setBorder(UIManager.getBorder("RadioButton.border"));
		tblveiculos.setForeground(new Color(0, 0, 0));
		tblveiculos.setToolTipText("");
		tblveiculos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblveiculos);
		tblveiculos.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Chassi", "Modelo", "Marca", "Placa", "Ano", "Cor", "Valor"
			}
		));
		
		JLabel lblRelatrioDeVeiculos = new JLabel("Relatório de Modelos mais caros:");
		lblRelatrioDeVeiculos.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 17));
		lblRelatrioDeVeiculos.setBounds(10, 209, 304, 44);
		contentPane.add(lblRelatrioDeVeiculos);
		
		JLabel lblNewLabel_1 = new JLabel("Opções do Relatório:");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(100, 116, 214, 19);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String OpSlct = comboBox.getSelectedItem().toString();
				if(OpSlct == "Carro mais vendido") {
					Rcmv Opcmv = new Rcmv();
					Opcmv.setVisible(true);
					dispose();
				}else if(OpSlct == "Funcionário que mais vendeu") {
					Rfqmv Opfqmv = new Rfqmv();
					Opfqmv.setVisible(true);
					dispose();
				}else if(OpSlct == "Cliente que mais comprou") {
					Rcqmc Opcqmc = new Rcqmc();
					Opcqmc.setVisible(true);
					dispose();
				}else if(OpSlct == "Venda mais cara") {
					Rvmc Opvmc = new Rvmc();
					Opvmc.setVisible(true);
					dispose();
				}else if(OpSlct == "Carro mais atual") {
					Rcma Opcma = new Rcma();
					Opcma.setVisible(true);
					
				}else if(OpSlct == "") {
					JOptionPane.showMessageDialog( comboBox, "Opçõa não é valida", null, DO_NOTHING_ON_CLOSE);
				}
			}
		});
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Carro mais atual", "Carro mais vendido", "Funcionário que mais vendeu", "Cliente que mais comprou", "Venda mais cara"}));
		comboBox.setBounds(309, 110, 321, 31);
		contentPane.add(comboBox);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main m = new main();
				m.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(4, 10, 86, 20);
		contentPane.add(btnVoltar);
		
		textField = new JTextField();
		textField.setBackground(new Color(255, 255, 255));
		textField.addCaretListener(new CaretListener() {
			public void caretUpdate(CaretEvent e) {
				preencheTabela();
			}
		});
		textField.setBounds(309, 170, 320, 30);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Filtrar por valor:");
		lblNewLabel_1_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1_1.setBounds(100, 180, 214, 19);
		contentPane.add(lblNewLabel_1_1);
		preencheTabela();
		
		 
	}
}
	

