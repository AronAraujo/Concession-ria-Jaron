package principal;

import java.awt.Font;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import bean.pessoa;

import javax.swing.JScrollPane;
import dao.PessoaDAO;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;


public class Relatorio extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Relatorio frame = new Relatorio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Relatorio() {
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 853, 600);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(165, 162, 170));
		contentPane.setForeground(new Color(165, 162, 170));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jaron Concessionária");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(52, 131, 150));
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 50));
		lblNewLabel.setBounds(100, 10, 640, 82);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Opções do Relatório:");
		lblNewLabel_1.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(100, 116, 214, 19);
		contentPane.add(lblNewLabel_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String OpSlct = comboBox.getSelectedItem().toString();
				if(OpSlct == "Carro mais caro") {
					Rcmc Opcmc = new Rcmc();
					Opcmc.setVisible(true);
				}else if(OpSlct == "Carro mais vendido") {
					Rcmv Opcmv= new Rcmv();
					Opcmv.setVisible(true);
				}else if(OpSlct == "Funcionário que mais vendeu") {
					Rfqmv Opfqmv = new Rfqmv();
					Opfqmv.setVisible(true);
				}else if(OpSlct == "Cliente que mais comprou") {
					Rcqmc Opcqmc = new Rcqmc();
					Opcqmc.setVisible(true);
				}else if(OpSlct == "Venda mais cara") {
					Rvmc Opvmc = new Rvmc();
					Opvmc.setVisible(true);
				}else if(OpSlct == "Carro mais atual") {
					Rcma Opcma = new Rcma();
					Opcma.setVisible(true);
				}else if(OpSlct == "") {
					JOptionPane.showMessageDialog( comboBox, "Opçõa não é valida", null, DO_NOTHING_ON_CLOSE);
				}
			}
		});
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Carro mais caro", "Carro mais vendido", "Carro mais atual", "Funcionário que mais vendeu", "Cliente que mais comprou", "Venda mais cara"}));
		comboBox.setBounds(309, 110, 321, 31);
		contentPane.add(comboBox);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main m = new main();
				m.setVisible(true);
				dispose();
			}
		});
		btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnVoltar.setBackground(new Color(218, 232, 236));
		btnVoltar.setBounds(10, 10, 86, 20);
		contentPane.add(btnVoltar);
	}
}
