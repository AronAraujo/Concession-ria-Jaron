package bean;

public class vendaMaisCara {
	
	    private String chassi;
	    private String cor;
	    private String modelo;
	    private String marca;
	    private String placa;
	    private String ano;
	    private double valor;
	    private String funcionario;
	    private String cliente;
	    private String data;
	    private String hora;


	    public vendaMaisCara(String chassi, String cor, String modelo, String marca, String placa, String ano, double valor,
	            String funcionario, String cliente, String data, String hora) {
	        this.chassi = chassi;
	        this.cor = cor;
	        this.modelo = modelo;
	        this.marca = marca;
	        this.placa = placa;
	        this.ano = ano;
	        this.valor = valor;
	        this.funcionario = funcionario;
	        this.cliente = cliente;
	        this.data = data;
	        this.hora = hora;
	    }

	    // Getters e Setters
	    public String getChassi() {
	        return chassi;
	    }

	    public void setChassi(String chassi) {
	        this.chassi = chassi;
	    }

	    public String getCor() {
	        return cor;
	    }

	    public void setCor(String cor) {
	        this.cor = cor;
	    }

	    public String getModelo() {
	        return modelo;
	    }

	    public void setModelo(String modelo) {
	        this.modelo = modelo;
	    }

	    public String getMarca() {
	        return marca;
	    }

	    public void setMarca(String marca) {
	        this.marca = marca;
	    }

	    public String getPlaca() {
	        return placa;
	    }

	    public void setPlaca(String placa) {
	        this.placa = placa;
	    }

	    public String getAno() {
	        return ano;
	    }

	    public void setAno(String ano) {
	        this.ano = ano;
	    }

	    public double getValor() {
	        return valor;
	    }

	    public void setValor(double valor) {
	        this.valor = valor;
	    }

	    public String getFuncionario() {
	        return funcionario;
	    }

	    public void setFuncionario(String funcionario) {
	        this.funcionario = funcionario;
	    }

	    public String getCliente() {
	        return cliente;
	    }

	    public void setCliente(String cliente) {
	        this.cliente = cliente;
	    }

	    public String getData() {
	        return data;
	    }

	    public void setData(String data) {
	        this.data = data;
	    }

	    public String getHora() {
	        return hora;
	    }

	    public void setHora(String hora) {
	        this.hora = hora;
	    }
	}


