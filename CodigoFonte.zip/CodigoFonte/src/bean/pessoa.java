package bean;

public class pessoa {
    String Cpf;
    String Nome;
    int RG ;
    String logradouro;
    String cidade;
    String pais;
    String estado;
    String data_nasc;
    String CEP;
    int numero;
    public pessoa(String Cpf, String nome, int RG, String logradouro, String cidade, String pais, String estado, String data_nasc, String CEP, int numero) {
    	this.Cpf=Cpf;
    	this.Nome=nome;
    	this.RG=RG;
    	this.logradouro=logradouro;
    	this.cidade=cidade;
    	this.pais=pais;
    	this.estado=estado;
    	this.data_nasc=data_nasc;
    	this.CEP=CEP;
    	this.numero=numero;
    	
    }

	public String getCpf() {
		return Cpf;
	}
	public void setCpf(String cpf) {
		Cpf = cpf;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public int getRG() {
		return RG;
	}
	public void setRG(int rG) {
		RG = rG;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getData_nasc() {
		return data_nasc;
	}
	public void setData_nasc(String data_nasc) {
		this.data_nasc = data_nasc;
	}
	public String getCEP() {
		return CEP;
	}
	public void setCEP(String cEP) {
		CEP = cEP;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
    
}
