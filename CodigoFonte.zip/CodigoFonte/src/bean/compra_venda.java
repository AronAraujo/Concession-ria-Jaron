package bean;

public class compra_venda {
    private String Veiculo;
    private String Funcionario;
    private String Cliente;
    private String data;
    private String hora;

   
	// Construtores
    public compra_venda() {
    }

    public compra_venda(String Veiculo, String Funcionario, String Cliente,String data,String hora) {
        this.Veiculo = Veiculo;
        this.Funcionario = Funcionario;
        this.Cliente = Cliente;
        this.data = data;
        this.hora = hora;
        
    }

    // Getters e Setters
    public String getVeiculo() {
        return Veiculo;
    }

    public void setVeiculo(String veiculo) {
        this.Veiculo = veiculo;
    }

    public String getFuncionario() {
        return Funcionario;
    }

    public void setFuncionario(String funcionario) {
        this.Funcionario = funcionario;
    }

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String Cliente) {
        this.Cliente = Cliente;
    }
    
    public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

}
