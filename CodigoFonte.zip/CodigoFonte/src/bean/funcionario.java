package bean;

public class funcionario extends pessoa {
	double salario;
	String data_adimissao;
	double meta;
	double RegistroFaturamento;
	double comissao;
	
	public funcionario(String CpfP, double salario,String data_adimissao,double meta,double RegistroFaturamento,double comissao,  String nome, int RG, String logradouro, String cidade, String pais, String estado, String data_nasc, String CEP, int numero) {
		super( CpfP,  nome,  RG,  logradouro,  cidade,  pais,  estado,  data_nasc,  CEP,  numero);
    	this.salario=salario;
    	this.data_adimissao=data_adimissao;
    	this.meta=meta;
    	this.RegistroFaturamento=RegistroFaturamento;
    	this.comissao=comissao;
    	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getData_adimissao() {
		return data_adimissao;
	}

	public void setData_adimissao(String data_adimissao) {
		this.data_adimissao = data_adimissao;
	}

	public double getMeta() {
		return meta;
	}

	public void setMeta(double meta) {
		this.meta = meta;
	}

	public double getRegistroFaturamento() {
		return RegistroFaturamento;
	}

	public void setRegistroFaturamento(double registroFaturamento) {
		RegistroFaturamento = registroFaturamento;
	}

	public double getComissao() {
		return comissao;
	}

	public void setComissao(double comissao) {
		this.comissao = comissao;
	}
}

		
		
	
