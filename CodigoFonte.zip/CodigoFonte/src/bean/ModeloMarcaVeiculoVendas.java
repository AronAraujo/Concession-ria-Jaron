package bean;

public class ModeloMarcaVeiculoVendas {

    private String modelo;
    private String marca;
    private int totalVendas;

    public ModeloMarcaVeiculoVendas(String modelo, String marca, int totalVendas) {
        this.modelo = modelo;
        this.marca = marca;
        this.totalVendas = totalVendas;
    }

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getTotalVendas() {
		return totalVendas;
	}

	public void setTotalVendas(int totalVendas) {
		this.totalVendas = totalVendas;
	}

    
}


	


