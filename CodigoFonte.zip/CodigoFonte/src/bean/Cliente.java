package bean;

public class Cliente extends pessoa {
		int CNH;
		public Cliente(String CpfP, int CNH,  String nome, int RG, String logradouro, String cidade, String pais, String estado, String data_nasc, String CEP, int numero) {
			super( CpfP,  nome,  RG,  logradouro,  cidade,  pais,  estado,  data_nasc,  CEP,  numero);
	    	this.CNH=CNH;
	    	}
		
		public int getCNH() {
			return CNH;
		}
		public void setCNH(int cNH) {
			CNH = cNH;
		}
}