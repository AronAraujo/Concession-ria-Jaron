package bean;

public class ClienteMaisCompras {

    private String cpfCliente;
    private String nomeCliente;
    private String cnhCliente;
    private int totalCompras;

    public ClienteMaisCompras(String cpfCliente, String nomeCliente, String cnhCliente, int totalCompras) {
        this.cpfCliente = cpfCliente;
        this.nomeCliente = nomeCliente;
        this.cnhCliente = cnhCliente;
        this.totalCompras = totalCompras;
    }

    public String getCpfCliente() {
        return cpfCliente;
    }

    public void setCpfCliente(String cpfCliente) {
        this.cpfCliente = cpfCliente;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getCnhCliente() {
        return cnhCliente;
    }

    public void setCnhCliente(String cnhCliente) {
        this.cnhCliente = cnhCliente;
    }

    public int getTotalCompras() {
        return totalCompras;
    }

    public void setTotalCompras(int totalCompras) {
        this.totalCompras = totalCompras;
    }
    
}

